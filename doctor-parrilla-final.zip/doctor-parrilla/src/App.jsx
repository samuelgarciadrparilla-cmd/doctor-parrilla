import { useState, useRef } from "react";
import React from "react";

const GOLD = "#C9A84C";
const GOLD_LIGHT = "#E8C97A";
const DARK = "#0A0A0A";
const DARK3 = "#1A1A1A";
const CARD = "#141414";
const BORDER = "#2A2A2A";
const WA_NUMBER = "595994389932";
// Link de reseña Google — reemplazá con el link de "Obtener más reseñas" de Google Business
// Ir a business.google.com → tu perfil → "Obtener más reseñas" → copiar link
const GOOGLE_REVIEW_URL = "https://share.google/D7XEt1nQQzynvpxG5";
const ADMIN_PASSWORD = "Diosmeguiara16.";
const ADMINS = [
  { nombre: "Admin 1", rol: "Gerente" },
  { nombre: "Admin 2", rol: "Operador" },
  { nombre: "Admin 3", rol: "Supervisor" },
  { nombre: "Admin 4", rol: "Coordinador" }
];
const LOGO_B64 = "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAUDBAQEAwUEBAQFBQUGBwwIBwcHBw8LCwkMEQ8SEhEPERETFhwXExQaFRERGCEYGh0dHx8fExciJCIeJBweHx7/2wBDAQUFBQcGBw4ICA4eFBEUHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh7/wAARCAC0AZADASIAAhEBAxEB/8QAHAABAAMBAAMBAAAAAAAAAAAAAAUGBwQBAgMI/8QAUxAAAQMDAgIFBwUKCwYGAwAAAQACAwQFEQYhEjEHE0FRYRQiMnGBkaE1NnOxsiMzNEJSU3J0krMIFRZDYoKTosHC0RckVOHw8SU3VVaU0nWD8v/EABsBAQACAwEBAAAAAAAAAAAAAAAEBQEDBgIH/8QAQBEAAQMCAwQGBggFBAMAAAAAAQACAwQRBSExBhJBURNhcYGRoRQiMrHB8BUjMzRCctHhFjVSYoJjosLiNlPx/9oADAMBAAIRAxEAPwD8hIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiKxaKquKsNpqIhUU1Tyje3iDXgZBx44x7u5V1TuiaSSovcc4b9ypvujyc+oDbtJ+orVNbozdT8L3/TIwwXJIy5jjfqtquzU2m208Rq7a2R0Y3ki9IsHeDzI7+5VZawJohUCDrG9dwdYGHmW5xnHdlZ3qiibQ3ueGNnDE4iSMdga7fHs3HsUajnc/1X6q+2nweGlIqKb2SbEcj88OCi0RFOXJIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiKb09p+e5YnmJhpM44/xn+DR/jy9fJeXvawXcVIpqWWqkEULbuK4LTbaq51HU00eQMF7z6LB3kq+xMt2nrVhzy2Npy5xHnyvx2D6h2D2o6ro7aYbVb6V9RVvIbDR0zS573nlnGdz7T4LRdNaGp9LW5/SD0mPjLqFnWUlqaQ5kT/AMVrux0hOMN3AO5zjalra1rQN/Q6Di49XzZdlRwwYQHdGQ+e2Z/Cwcc+fmeoa5XJQXGi1pbJLk7q6uso/Kn05B/3eNzX9Ww78ywNd4cQyOahtfSRvvjWMDQ6OBjXkHmdzv7CB7FY47jUXe8XbXF9HDJWPdIGg+izIGG557AMHqVCr6mSsrZqqU5fK8uPhnsU+nDnP3nagWNtL8u5U9bKYsOEbjcyPL89bWsCfzG5XwRFKUtnmlsVVd3uDIoS0Nb2vJcGk+oZ9/tUwkDVUMcT5CQ0XsCe4KLREWVrREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREVl0ZZY6xzq6rYHwxu4WRnk93j4D4n2rxJII2lxUuio5K2dsEWp8ute+mNPNmjZcLjgQYLmRk44h+U49jfr9Ss1mpr7rK9mw6QgBDB/vFcfNigbnGcjZre7G57AvvprT9w6RdSmw2qYwWylw+4VoGWgZ2A7zzDRncgnkF+ntJacs+lrNFabJRtp6Zm57XyO7XPdzc4/8hgbLl8WxhtJqLyHQcG9Z6+pdhBC1rTTUZszRz+LzyHJvzzvWej/AEDpno3s0twklifWMiL6y6VOGkNA87hz6DPDme0nksP6QtV1nSbqTiaJqfTNC8ilhOWmZ2ccbv6ZB/qjbmTmwdN+spdYX+XR1mqXMstA8G4Txn8IkB9Ed7Wnl2EgnsCzrVl0ZbaBlroiGSGMMIb/ADUfd63b+8ntXjCqKXf9JqDeV2l/wj9ergvBbAITI4WgYdP63cuzmfkRes7u2pmFupS0U0Bw7g9FzhsMeA5D/sq2iLq42Bjd0Lkayrkq5nTSanyHADqC94Y3SzMiYMue4NA8StLultbNZZbXCAA2IRxdnnN5e8j4rNqSQRVUUpAIY9riCeeDlaxL98f4uP1qDXvLSwhdZsfTRVDKhjxqAO43usjcC1xaQQRsQexeFdtWafdVmS4ULQZ8cUsQG8ne5vj3jt7FSVMhlbK3eC5jEsOmw+cxSjsPMc0REW1QERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERF5aC5wABJOwA7VoNza+0adioaRpdUScNNGG83Pd6RHjz94VN03F1t/oWcLnDr2EhreI4BydvYtP0hSR3fpi0pbpRxxxSuq5G9mWBzx6/vYUCtkDLE6NBce4LpcGBio55m+07dYDy3jn5L9A9FekafRejaS0MjYKstEtbI3+cnI87fuHojwHiufpo1HLpbo4ulzppDHVuYKemcDgtkkPCHDxaOJ3sVxGceKzT+EzRVFb0S1zqdvF5NUwVEgAyeAEtJ9nGD6sr5nRO9KxBjpzfecL+PyFfVTfR6Nwi4DJYLYoBatOmdzC+QxGqlBPpHhyB7se8qgVU8tTUSTzvL5JHFznHtK0y2zR19pglc0PZNCGvaRsduFw94Kp9x0pcoZ8UbBVxuPmlhAcPWD/hkL6VTStD37+t1Cx6gmdSU5pml0Ybw5nO57VB0kogqYpjGyQMcHFjxlrsHkR3K0ai01EYTXWdriwgPMG5JaRnLe3ljZcFr0vcamVhqYzSQHBLn+kR4N5kq+xs6uJjWFwaxoa3LsnAAA/w3Xqpqdxw3Dc8VqwHAzVQyCqZutNt0nI36urnwKyVahZ6nyu1UlSSCXxDix+UPNPxCpWtKFlHeC+JobHUN60ADAByQ4D2j4qy6IdxaejBcDwzSDAGMDY+3mVisIkhDwvey7ZKPFJKZ/Ig9oOvzzXdLdKaC5Oo5+KBwaxzJCfMdxDtP4pyDz225qD1fYDMX3Gij+6+lNE0el/SA7+8e1XTSMNDUdIlnt10pmVFuvMM1tqmPGGuyOJmD2OD+Eg8xthfHWVgrtA6obZq6eSptNX51srZPSxsOreeWRsPDY8jtBjnbHKGMycRe3MaG3WLaeCs62VlTJJSV3sh1mu4tJzF+qxAv481jyK3a2soaHXOljDRn/eGAYA7OID18/E+KqKuopWyt3guFxCgloJzDLqPMc0REWxQkREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREVmsVobddNVDWdU2pZU5iccAnzRlpPYD7sj1qsq39HcwxW0xI4jwSAY3wMg/WFoqHObGXN1CtsDgiqK1kM3suuPI281VKiGWnmfDNG6ORji1zXDBBHYvmtJvdko7q3ilBinxhszRv6iPxh8VTblp26UWXGnM8Q/nIfOHtHMe0LzDVMlHIrfimz9VQOJtvM5j48vnNNGyCLU1A7ge/MvCAznkgj/FaboGeO39NOlKyUgMnL6XiJOA5zXtHxeFklum8muNPUO26qVrz7CCr/qoSw0Da+lc5tRb6hlRC9vYQ7n9k+xR62PpDuHRwLfFTcIHSYbPu6sLX+GvkCv090nT11L0eX6rts0kFXT0L5opGOw5pZh2R7AfXyXnS90tuu9BU9dJEyWkulIY6qEcgSC2VnsPEPcV2WypptVaQp6rbya70ALgOwSsw4ezJHsWE/wadVPsGpLh0f3eXgEtS/yTiOzahp4Xx/1g0Y8W+K+eU1G6Wjl3R9ZE6/XbQ+FrqzmqRHUs3vYkFu/h43sqjU2is0Xqut0fc38Qa7rqCY8po3ciPWBy7HBwXYcY3xgbnPJb70raDoNc2IQOc2mudNl9BWbgxO2JDsblpxv2g4I8fy5rx14s8Mum77R1FHdIZW9a7izHURji88HtBPCcjY49g6nDatmJtBvZ49ofEdR8ipUGKnCKd0UguB7B/wCJ5W4cwuy5amtlIHtheauYbAR+hnxd/plRmj66ruGoaupn4HF1Mc9gjbxtwGj14HqJVRVw6PICGVlU5ux4Ymux7T/l96vZII4YXEKnocWrMVxOFshyBvYaZZ/N11attdTdK6hipmnDYndY92Qxg4zjJ7/Abqat9LFQ0UVJDngjbjJ5k9p9pXRknAyfALirq8RTx0FHE+suVQeCnpYW8bnPOwyByHhzPxVeZHytEY0C7L0Wkw2WWuld6zvmwHEqa6Pqaa69MWm6KDidHb3Pr6jhdswAbZ9zR/WC3jpQ0jT6z0ZV2aRrRU8PW0ch/m52g8Jz2A+ifAlQvQr0fSaOttRX3aRtRf7jh1XIDkRN5iJp7cHckbEgAbAZ0M8lxuLYiHVjX05yjyB5m9yexUbIzUCSSYW6Q3tyFrAdtgvx7YKiWrt8tJcYiKmmc6mqo3+keY3HYcZHraVQbrSOobjPSOOeqeWg947D7RhbB0pW1lm6b7qyItjhulK2tDScAvcMux3nia/3rN9fxNZeY5GluZIGlwB3yCW7+wBd5QzCQh7dHgOVTirTUYWyV+b4nFhPMcPh5quoiK0XIIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIpXSlaKG9wve4Nik+5SEnYNdtn2HB9iikXlzQ4EFbYJnQStlZq0gjuWlXr+MmVdvNt6syyz+TOZI4Bjy7HAHEnA3BwdsZ5r609xZ5XLQVscluuUDuCalqfub2O7QM4z8D4KMslTDftPvoZ5OGdjBG89u3oSeO4GfV4rVNEfyZ6VrP8Aya1tS9Xqq1R9UKuN4ZPPG3YPa78cgcw4EcnDmcUNVIKeO8jbhupGoHA24jnyX0B+JVDJ21NM67JQCGnTeGRbfgfIqmkvaSHAAkYPEwEke0KH1ZURU1hnY53C6ZojiaDji3GceAAWi13QDeYC6Oy65cKckYjqYntLR62kj4BTGnegS2R3Jtw1Xfqq/PYdoQ0xRnfYOPEXEeAwoQxagjtIZb24AG63VWJ1E8D4Y6fdc4WJJFs+zMq49BjJG9EWnGyte1xpCfP54Mjy0+rBGPBfnD+EFRGzdMN1lpC6AzPirI3MPCWuexriQRyPFkr9gsENNThjBHDDEzAAw1rGtHuAAHsAX4x6c9R0uqOkm5XCgl62ij4KankByHtjbw8Q8CeIjwKgbNSPnxCaYD1XAk95uPiqDG2Nio44ycxbyC37oR6VqLV9BDaLxUMg1DG3hIdhorMfjs7OLvb7R3C6610hYNYWzyG+0LZ2tyYpWnhlhPex3MercHtC/C0T3xSNkje5j2kOa5pwQRyIK2DQ3T5qSzQxUd+po75TMHCJXv6uoA8X7h3tGfFSMR2cljl9IoDY62va3YfgtNHjUb4+hqxcc9fFSOqf4Ot6gqHyabu9JW0+ctiqyYZQO7IBafXt6lx0nRx0r0lIKOHTNrDQ3LH+UxDgxjukxk89wSd1p9o6etAVsYNXPcLa/tbPSl4z64y76gpf/bD0bcXD/KmD1+TTY+wtH0ljUY3JYN7taT7slLhhoY3GSnnLCeTgPfms0s/Q5r66P/8AHb7b7NTO9KOkHWy4zkjzcD+8tZ6P+jrTGiYi+1UhlrXNIkrqg8czweYB5NHg0DPblVi89PmgqKLNFJcbm/sbBTGMe0yEfUVlmt+n3U94jfS2GCOxU7tjIx/WVBH6ZADf6oB8V4dT4ziQ3HjcYf8AEeGpWZKyhp3dI55kfzJ3j4nILZemDpQtehqCSkp3RVl9kZ9xpc5EWeT5cch2hvM+A3Ud/Bku9zveirpcLtUPqKmW8TPdK8bvLo4yfDGewbBfk6eWWomfNPK+WR7i573uJc4nmSTzK/ZvQZp6XTXRnbKKqZ1VVOHVdQ123C6TcA92GhmfUV6xbDafDMO6Nub3EZ8cs+4LTh9bNXVm+cmtBy+eKzDp/cJOmO1MY4Ew2bLwTjALpeXfz7FknSG/Nxpo/M82DOzMHdx5nt5exXXUF4bqrpKv+o4HF1GHiioznZ7G4AI9YaD/AF1nGrKttZfah8buKNhEbD3hoxn2nJ9q6LC4HRNjY7VrRftXvEJg3CnH/wBkhI7ALX8QopFo0mlbJC+WHyeaThcWh75jnYnfbA/7LkmsNoOpqembRBkD7dJO6Nsj8F7XPAOSSfxRtlWDayNxIHDNQZ9maynax0hHrENGfE6cFREWjS6bsj88NEY8jHmTP295P/QURctHjBfbqgk/m5iN/U4be8BYZWxONr2Xqp2VxGBu8Gh3YfhkfBVBF9KiGWnmdDPG6ORhw5rhghdum6GK5Xykop3PbFNIGuLDg48FKJAF1z7Y3OeGcdFHItEi03ZGtaTROfuCeOZ++3I4I27V9P5O2Piz/FrMd3WyY+0ofp8XWuobsbiBGZaO8/os3RaDVaXs8rCI4pad2cgskJx7HZVX1DYZ7Ueta8TUrnYbJjBB32I7Dt6ltiqo5DYHNV9fs/W0LOkkbdvMZ/v5KGREUhUiIiIiIrxY9O2qW00lVPDLLJNFxuzKQM5cNgMdwK7/AOTtj4Gt/i5uQPS62TJ9fnY9wUR9bGxxBuulptlK6pibK0tAcARcnQ9xWcItFk03ZHN4RQmM45smfn4khQd70oYIH1FvlfM1gyYnjz8eBHP1bLLKyJ5tey8Vey+IUzC8tDgORv5ZFVZEUjpyhbcLxBTyAmLJdJj8kDJHt5e1SXODQSVQwxOmkbGzUmw71HItI/k9Yv8A00f28n+qjNUWG3Q2eWooqXqZYSHHEjncTc4I3J7wfYorK2Nzg0LoKnZWup4nSutZoubH9lSkRFLXNoiv9Jpmz+TRufBLI58TSS6Y7EgHIxjx966XadsZxi2sGB2Syb/3lCdXRA2zXUxbIV8jA67RfrP6LN0Wiy6bsjwQKIxbYzHM/wB+5P8A0FX77paSkhdU0Ej54mjLo3Dz2jv25j3L3HWRPNr2Uas2Zr6RhkLQ4DWxv5ZFVpF5C0R2lbLAXQmCaUgY43zEHOxzgYC2TTtiF3KFhuE1GJOc2G2Wt1nSLSHaesTjtbWN9Usn+Ll85tNWWRpDaR0ORzjldt+0T/0Fo9Pi61cHY3EALgtPef0WdorNfdLSUkDqmgldPEwFz2PAD2gdvc4e4+CrKlRyNkF2lc9WUU9FJ0c7bH50XRQVlTQ1IqKWUxyAEZAzkHmCDsQuoXy6tu1Pdoqt0NdTlrop4mhjmkcj5oH/AG2VloNMWuahp5nmo4pImudiQYyQD3KB1Xbaa2V0UNN1nC6LiPG7Jzkj/BaGTxSv3bZq1q8Gr6Kk6V7vUuDYE6nQ25q0/wC2npM/9zP/APiQf/RP9tPSZ/7mf/8AEg/+ijNGWe211pnqqymM8gqBG37o5oA4c9hC7b5Y7PBZ6uaCh6uWOLiY7rnnByOwnCiOp6Br+jMTb/lC3QYbic1J6W2T1bE+0b5Xv7ly6g6UNeX61TWu6ainlo5hiWNkUcfGO4ljQSPDkqah5orCKCOEbsbQ0dQsudklfIbvJJ680RS2kaOnr7/BTVcZkhLJXOaHFueGNzhuN+YCuY09Ys/Jo/t5P9V4mqWRGzlb4bgNViMZkhtYG2Z/ZZsi6brFHBdKqGJvDHHM9rRnOAHEBcy3g3zVO5pa4tPBERFleV9aSeSlqoqmLg6yJ4e3iYHDIORkHII8Dsrrcel3pEuFBUUNXqSV0FRG6KVraeJhc1wwRlrARt3FfDSljt9RZ21NdS9dJK9xYTI5uGjbsPeCpX+T1i/9NH9vJ/qq6eSlc/6xoJHMA27F09Fs5iUsAlicA1wvqRl15KlUt9udLQChp6hscA4sARM4t+fnYz8VGKV1VQR2+8yRQRmOB4D4mlxOARyye45HsUUpzN0jebxVDVdMx5hmJJZcWvpbkthrfwyf6V/2iqjq651Vr1DSVNMWcQoeDD2BwLXOfkEe1W6t/DJ/pX/aKonSJ8rUv6o37b1U0IBlIPJfStrXuZQNc02IcPcV7Uesapr8VdLDKwnnHljhv7R8FbqOpgrKWOpppA+J42PaD2gjsIWUq2dHlS/r6qjJ8wsEoyeRBAOPWHfDwUmqpWbhc0WIVBs7tBVGqbTzu3muyz1B4ZqU1faoq23SVTGtbU07S8O/KYObT9Y9veq1ob52W76YfUVoTMF4DuROD6u1UHR7Gx60oo2u4mtqCAe8DK80chdG5p4LdtRRMhr4Z2C2+c+0EZ+fkr2372PUqpqi/wBxob9U0tM+JkMRa1rTED2A7k753VrH3sfoqkanoKu4atr4qOB0rmuaSAQMAtaMnK0ULWFx3grfayaojhjFO4gl34b3OXUpzS18kuplgqI2Mmjbx5YMBzc45dmMj3qYqaZtZTS0bhkTsMftPL44PsUJpKyT2wy1NU5omlYGBjXZ4RkE5PLOQOSlLzXtttulqyQHgcMQzgueeWPVz9i8ShpnAiUnD5J24SXYhyN7626+vz0WXoiK8XyVECIERadp/wCb1t/V/wDO5empbhNa7Qysp2ROkNSIyJG8TcFjjy9YXvp/5vW39X/zuXDrzfTUYH/Gt/dvVKxodVEHmV9TqpXw7PtfGSCGMzGR/Cou36vnfWtbXwwNge4Bzoo+Es8QM7q4bg9xB7Fm9ostbW1jI3U80cIcBLI5pAaO3n247FpL3cT3OPac7r1XMjaRu6rVslU1tRE81BJblYnvvnx4LPNZ0bKO9vMbeFk7BMBjYE5Bx4ZBUr0eUuGVVc4HfELD/ed/l964Nez9dfBFknyeFsfq3LiPe5WvTdL5HY6WIgcTmdY/A7Xb/VgexSJ5C2mF9TZU2EUTJcdkLB6rC4+dh5nyXbLURQvhZJguqJOqZvyOCc/AD2r2kjZNE+GQAskaWOz3EY/xVX1vWmnr7a1ucwnygjPM8QA+yferUS13nMOWu3b6jy+CgPjLGMeOK6+krm1dVUUzsw2w7iM/O6yepidT1EkD8ccbyx2O8HC+an9dUpgvRnGOGpYJBjv5H4jPtUAryN++0O5r5JWUxpah8J/CSFq9L+CQfQs+yFXtW3qvttbFBSOjY0xh5JjDiTkjG/ZsrDS/gkH0LPshVLWtNPWX+mpqaJ0sr4PNY3mcFxPwCqKZrXTHe0zX03HZZYsKa6FxDvV018l0aa1LUVVdHRVzY3GU8McjRwkO7M9hBVpBI3HNVDTWm6yKvirK9jImROD2xuw5zz2ZHID193JW6R7I4nySvDI2N4nuPJo7SsVYj3wI/JZ2bkrPRHOrSbXy3tbWzvfh2rNdQ08VLfKuCAYjbIeEYxgHfHszhajWfhUnrH1BZTdqvy66VFXjhEry4DGMDs9uMLVqz8Kk9Y+oKRXX3G31VPsiWOq6gx+zw7LmyrOsrtW2ySjZRujYJI3PcTGHEniI7ezAXNpvUlTW18VDWRxuMp4WSMbg8WNsgbHPwXjXcE1XcbbTU0ZlmdC/DG8z57j9S9dL6erqS4w19ZwwiF3ExnHlzjjblyHrXoNhEALrXt3rRJPibsYc2nc4tDrcd0DjfgFbAcbj1rNNQ0rKO9VdNGAGMkPCAc4B3A9mVpE0kUEL5ZnhkTG5c49gWZXesNfc6irOfuryQDzA7B7sLxhwN3HgpW2z49yJn4rk93/33LR7T8lUn0DPshVLpA+VYPoB9oq22n5KpPoGfZCqXSB8qwfQD7RWqk+38VP2k/k4/wAVMdH/AM3p/wBcH7tSGovkGv8AoD9YUf0f/N6f9cH7tSGovkGv+gP1hJvvXePgsYX/AOPH8r/e5Zmea8Lyea8K5Xy9TugvnRT/AEU/7l6v49L2qgaC+dFP9FP+5er+PS9qqMQ+0HYvpmxX3N/5vgFl98+Wq79Yk+0Vxrsvny1XfrEn2iuNWrfZC+cT/aO7Si9o2OfI1jBlziAB4r1U1oyl8pv0LiCWQAzO9nL+9hHuDWlx4L1TQOqJmRN1cQPFX2kp20lJDStwRCwMyO0gbn2nJXmGpiqet6oD7jK6F+DnLm4yfble5e2NpkefNYC8+oDJ+pVbQdY6aWvilfmSRwn9ZJId9YVG2MyMe88F9cqKxtJV09I3IOBHgMl7dINLx0lNWNaSY3GN58DuPiD71S1qF5pfLbTVUwBLnxksA7XDdvxCy9WNC/eityXC7XUnQ1/SDR4v3jI/A962Gt/DJ/pX/aKonSJ8rUv6o37b1e638Mn+lf8AaKonSJ8rUv6o37T1DoPtT2Lp9sP5c38w9xVZVn6PYeK41M5a0iOHhBPMFzhy9gcPaoW22uuuEgbS073gnd5GGN9bjsFoFjtsdqoBTsd1j3HikfjHE7HZ4Ds/5qbWTNbGW8SuV2Yw2aorGTW9Rud+vgB3qQZjjbnGMjOSqDo9zX61onsGGmpJaM523Vp1NcGW+0TOD8TStMcQ7cnmfYCfbhVLQ3zst30w+orRRMIjc7mrfauqa+tggac2m57yP081fx97H6KgY6inp9cXY1E8UIcxoaZHBoJw3bJU8PvY/RWf63+dFd+mPshaaNgk3mnkrbairdRiCdguWuOvYVoQI2OxHP1qj66payOsZUzVDp6eTIizt1eMZbgbe3tU1oaqdUWUxPOTTycA3/FIyP8AMuvU9MKqw1bNuKNvWt27W7/VlISaefdPYsYm1uM4R07bggbwF+I1HXobLNkX2oqaasq46WnbxSSO4WjOFMXLTklJUUNLHVNnqatxHCGEMbjG+eZHPsHJW5e0GxK+ax0k0sZkY27RYX6zoO1QKBfWqgmpah9PPGY5Y3cLmnsK+QXpaCCDYrTtP/N62/q/+dy83r73af8A8xB9RXjT/wA3rb+r/wCdy4de/NqP9db+7eqaL713n4r6fWm2zrT/AGM/4qfqC7ifLK48JJPG923PvKgLxqahooy2kkjq6jsDd2N8Se31D3qgFziAC4kDlkrwpUdAxpu43VBW7ZVMzCyFgZfje57tPcu62QPud5hhkc5zp5cyO7cZy4+7JWnE5JIHqCpXR/S8ddPWOAIhj4G5/Kd/yB96uU8zaeCWpfkthY6Q48BlR6529IGDgrjZCAQUUlU/8R8m/vdVWstZv+orgfKeohpeGIOMZdlwGMc+8OKtFLCKekgp+s63qomsL+Hh4sDHLJ8FS7BqGC20ckctNLNNLKZJHh4APd2ev3qx2G+QXaSWOOJ8T42h2HOB4hnB923vWapktt23qhY2eqcP3+lL/r5L3GfE3tyXJryl660MqQBxU8m57eF231gKiLVqynbV0c1I4DEzCzfsJGx9+Csre1zHuY4YcCQR4qRQP3o93kqXbGk6KsEw0ePMZe6y1Wl/BIPoWfZCgrlUQUut7fNUytiiFO4FzuQyHgfEhTtL+CQfQs+yFTOkH5Wg+gH2nKHTN3piO1dPjsphwtkg1aWHwsrrE+OSNskUjJGOGWuY4EH2hQGuqaqmtrZ4p3dRCR1kIAwf6eeZ9R5dnao3o/q3MrJqJzvucjC9o/pN/wCWfcFcnxsmY6GUZZICxw8DsVhwNLNzXuKVu0GFuv6rjcZHiNO0aZH91kw5rYKz8Kk9Y+oLI6iJ0FTLA/0o3OYfWNlrlZ+FSesfUFJxH2Wqg2JBE0wPIe8qt3uWKn1ZaJqiRsUXVPBe44A3eN/aVORPZLG2SKRkjHcnMcCD6iFUukb8It/0Dv3jl69H1W4VNRQud5j2da0H8oYz8CfcF4kg34A8agKbR4wabF5aRw9V79eINgAu/XFJXT0XXwTONLEAZYB2dnH48+3llUZazLEyeJ8EnoSNLHeojBWV1ML6eplgk9ON5Y71g4K30Eu8wtPBVG19B0FU2dt7P78x8NMlptp+SqT6Bn2Qql0gfKsH0A+0VbbT8lUn0DPshVLpA+VYPoB9oqJSfb+K6LaT+Tj/ABUx0f8Azen/AFwfu1Iai+Qa/wCgP1hR/R/83p/1wfu1I39rn2Ouaxpc4wkAAZJ3CTfeu8fBMKBOzxA/pf73LMjzXhdBoqzP4JP/AGZ/0TyKs/4Sf+zP+it95vNfM+gl/pPgpXQXzop/op/3L1fx6XtVC0K1zNVwse0tc2KoBBGCD1L1fR6XtVViH2g7F9H2K+5v/N8Asvvny1XfrEn2iuNSd6pKp94rXNppnNNRIQRGSCOIrk8irP8AhJ/7M/6K0a4WGa+ezQS9I71TqeC51dej+l4KKorHAZleI29+G7n4ke5U2WKSJ/BLG5jsZw4YK06z0vkVqpaU+kyMcX6R3PxJHsUWuktFYcV0OyVGZa/fcMmC/ech8T3Lm1VP5Pp+reOb2iIb/lHf4ZXJprT7rbPHWvrQXvhIkh6k7cQzjiz2HHZ2Ln1zVxRy2+nlYXxiTr5Wg4JaDgD7S8O1nTOcSaGbc5++D/RRmMlEADBre6vaqqw9+LPfVvt0e6G666nTkclaASDkcxuFmmpKQUV7qYGA9Xx8TMj8V24+taPTStnpop2ejIxrx6iMqq9IdN51LWtB3Bieezbdv1n3LzQvLJS08Vu2up21NA2oZnukHuPyFdK1jxWVGWOH3V/Np7yos5brKjewEPFpmIIG4PHKMrOW1tY1nA2rnDeLiwJDjPfz57LzPcK+on8onramWbh4OsfK5zuHuyTnG52UmOiLCTvaiyo63attWyNpituua7W97cNOK1R/GGlz+INHa7YD3qHuWobZRMcBOKmUco4TnJ8Xch8Vn08807uKaWSR3e9xP1+oL5rDMPaDdxuvVVtpUPbuwRhvXr+g967bxcqm51ZqKggY2YweiwdwXdob52W76YfUVCLyCQQQcEKdujd3QuSE7zMJnm5vc9a1sRydWPub/R/JKz3XAI1TXAjB4x9kKK6+f89J+0V83OLnFziSTzJKjU9L0JJvdXuN7QfSkbY+j3bG+t/gFZOj+p6u6S0h5VEfmgDcubuPhxK89UXDhfG8scMOHCeR2PwWRNJa4OaSCORC+nXz/npP2isT0nSv3gbLbhG0pw+m9HdHvC542yPDQqa08YrVqp0FW1reB0kPG/bgduAf8ParDA11ZrWeThcWW+ARjG/nn/8Ap3uVAJLiSSSTzJX0iqJ4mSMimkY2QYeGuIDh3HvWySDfJdfO1lX0WLejMbEW3YH79r53AyHuUjq6eCov9RJTua9g4W8TeTiGgE+8KJCItzW7rQBwVXPMZ5XSu1cSfHNahp1jzp22kMcR5PzAP5blH6/a5umow5pGaxvMY/m3Khtmla0NbK8AcgHFeHySPxxvc7HLJyorKTdl6S66OfaTpsOFD0dsmi9+VuFurmvRERTFy60XRtE+nsELurfxVBMp808jsPgM+1eutpnU1gkYWuDp3tjG2NvSP1fFUBs0zQAJXgDkA4rw+SR4Ae9zscsnKheiXl6QldUdpQ3DvQo4rera9/E2txz48V6KX0hUimv9PxOIZKTE7+tsPjhRCKW5oc0g8VzdPM6CVsrdWkHwWvdXJ+beD+iVnWsqN1HfpvM4GT/dmDGNnc/iCovyif8APSftFej3vecvc5x7ycqLT0phde910GNbQtxSFsZi3SDe9792gWr0kbzSU5DH/eY/xT+SFS+kIFt3gDgR9wHMY/Gcq8J5gMCWTA/pFer3vecvc5x8TlIaTo5N+69YltJ6dRil6O2md76dVl2WGrFDd6apcSGMeOPf8U7H4ErUOrf+Q8+Iad1kK+gnmAwJZMD+kV6qKUTEG9lpwTaB2Fsews3gTfW1vI65KZ1tSOpr9JJwFrahglG3adnfEFaNVseal5DHEZG4ae4LHnve85e9ziO85XsJ5gABLIAP6RWJaUyMa0nResOx9tDUyztiuH8L6Z35K09JDS2ot4cCPuDuYx/OOUFp2qFHeqWdxAYJA15J2DTsfgVwve95y9znEd5yvVbmRhse4VVVVc6asNU0WJN+xa8YpASCx+23olZ7raldTX+V5bwicCUbY58/iCofr5/z0n7RXq973kF73OxyycrRT0phde91b41tC3FIRGYt0g3ve/wC1C0/JVJ9Az7IVS6QflWD6AfaKrnG/wDKPvXgknmSfWsQ0nRyb917xPaQV1H6N0dtM7306rK+9HoLtPVAaCT5YOQz/NqwdXJ+Q/8AZKyNkj2Z4Hubnng4Xv18/wCek/aK8zUXSvLt5bsL2q9ApWU/RX3b571tSTyPNa1wS/kye4rzGyXrGebJ6Q7D3rJOvn/PSftFPKJ/z0n7RWv6O/u8lYfxz/of7v8AqrTZt+kqqxvmas9vmSK4dXJ+bf8AslZE1zmu4mkgjtBX06+f89J+0VvqKTpnA3sqfBto/oyJ0fR71zfW3LqPJazwS/kye4rzwS/kye4rJevn/PSftFOvn/PSftFaPo7+7yVx/HP+h/u/6q23mifW64padzHEcDHvBB9FuSfgFbCyQkkxvyd/RKyTrZOPj6x/FjGeI5Xt5RP+ek/aK2yUZeGje0VdRbUNpZZZehuZHX9rTkNO1Sesqk1GoKhufNhIhHhw7H45UOhJJydyimMaGtDRwXL1E7p5nSu1cSfFaFoic1NhZGGkup3mM432PnD6yPYuvU1FJVWKqj6t/E1vWt8wndu/1ZWaMkkZnge5ueeDhe3XzfnpP2ioho/rekBXSx7T2oPQ5It71d29/DK3BXis0pp2jDDV3Oop+PPD1kjBxY5483xCqF8p6Oluk0FBUeUU7ccEnEDnYE7jxyr9rKqtNM2k/jSgfV8XH1fC7HDjhz2jnt7lnt0kpZq+WSigMFO4+ZGTktGFNXKKc0rY7beqGdrqioirYs+aCODB9F3LOM7Hdfa2aZpmWeouN6lqIBE5wDIy0HDTg8xzLtguXo/hq5NQsfTu4Y42EzHGQWHbHtOMe/sVl6Q2VVTY2y08wkgikzMGnOQPNG/9E5BHj4IsrOjjOyu0+lbHS0VPU1t0npxLExxLsYLi0OIGB4qkLTr+y0Ps9u/jmWSOEMiLeDO7uqbscAnGMosKo6t0820NiqKaczUsxw3ixxNOMjlzBHauLTNvhud4io6h8jI3hxJYRnZpPapPWd9pLlDT0VBGfJ4N+NzeE7DAAHcAufQXzmp/0X/YKIpmr03pelkfFPeJIpmDdj5WAg4yM+aqQrvqiusEV1q4au1STVYGDKH4BJaMHGezZUhEVzbpeyw2mjra65zU4nijeS4Dh4ntDsDYn/so/VWnYbXSw11HVmemlIaOLGdxkEEbEEK0177SzStrN5jfJTmngDeHi2d1Q32I7MqN6R+tgtVDTQtjFEDgYySC1uGjPLHCdvaiyqzpyltdXVSsutY6libHljmkDLsjbcHsyrNLpbTkVE2tkuVU2mfjhkL28Jzy/F8CqKFeb3/5b0X/AOr/ADIsKpXmGjp7nNDQTmemaR1chOS4YHgO3KnbBpeGe3i53aqNLSkcQAIaS3scXHYAnlsSfcqstB1gwzaLpX0bSYm9S93CdgzgI5esj1Ii4a7SlvqaCSrsNcagsz5jnBwdgbgEAEHt3CpivXRcyYR1srjiBz2AZGxcM5OfAHf1hUmpINRIQQRxnBHI7oitdp01a2WiK5XutdC2YAsDHhoAI2ycEk9uAobUtHbKOqiZa6w1Ub4+Nx4g7hJJwMjtx3qdsWpKCS3QWq9UgMbWhjZCziaQORI57cshcGubLS2qoglo+JsU/F9zJJ4CMciezft3RFW0RERXeDS1jbaaaura+op2ysYS50jA3ic3OB5vr9yrepKS3Ude2K2VZqoTGHF/EHYdk5GwHgrtcp6Cn0fb5LlSOqoMQtDGuxh3VnB5jsB96ot8nt1RWNktlI6lhEYBY52cu3yeZ8ERSejLHSXo1XlUk7OpDOHqiN8555B7l9RpmOPV8Vonkm8lmDnxyNxxFoa4+rORgrv6LnmP+MpGkhzRG4EHtHEVNWCqbe6OguWWmro5HNl49tywtf7wQ4eIwiys/wBRUUVuvNRRQOe6OIgNL8Z3aDvj1qPUzrb50Vv6TfshQyLC+tHEJ6uGFxIEkjWkjsycK7VGkbFDVsppLrNHLMSIo3FvE7mB2Y5jwyqbavlOl+mZ9oLRtRSWKnu1JVXaV7Z4ml0LOFzmkcR3IA55z29iLKompbQ+zXDyZ0nWxuYHxv4cZHq7wQQvfSdpZeLoaeV72QsjMjyzGe4AZ8SF51beG3m5CaJjmQxsDIw7GSMkkn1kqzdHdP5NZqu4Oc1jpncLHSbNAaNiT3cR+CLChdZafgszKaWlkmkjlLmu6wgkOGCOQGxB+Cra0i7UL6rRBpnTQ1U1NGHiSI8QPBnke/gKzgc0RXafSljpaSnnrbrNTiVjDl+AC4tDsDbxUTqzTzLQyGppqgzU8p4RxAcQOMjcbEEdquF/dZ22qhF6je6JzIhGWlw4XdW3c8JHZ61DdJrqhkFDC1rBS+djGc8QAGD4BuMe1FlVjTlDFcr1T0U7ntjkJ4izGdgTtn1K0nSFlNW+hbdZvLBHx9X5pLQQCCRjfYg4B7VAaH+dFH63fZKvobZ5NTTlsTf41ihYXuPFu0sbgjfGwLQcAHcoizG7UMttuM1FMQXxOxkciMZB9oIKk7PZaet09X3KSaVslNnha3HCcNB3XFqR9XJfax1cGCoEpa8M9EY2GPDAGFYdL/Me8/1vsBEVOU/qOzUtttdvqoJJnPqWcTw8jA81p2wPFQParhrj5v2X6P8AyNRYVOVk0zYaO52itrKiWdskBIYGEYPmF2+R4Ktq9aC+bN0/SP7soioqLyvtb6Z9ZXQUsYJdNIGDA7zhEVvsWjqKss9PVVVRUMmmbx4YWgAEnGxGTtgn1qnVUL6aplp5MccTyx3rBwtWqmiO5W9kVXTxQQNc0wvfh8gLeBuB28lR+kKjNNfnVAbhlSwSA9nFyd8Rn2osrg01aH3m4eTiTqo2ML5H8OcDlt4kkBT1wsmlKeKoiF0mbU07X8THSNJLh+LjhAznbAKgdNXaaz15qY4uujczhlZnGW5Hb2HON1cRSWXV9NJPTRPhqwQ0ycPC4PPLixs4bev1Iiu8lqpJMdYzjxy4gDj3hZP0kU8VNqqeGFoawRxkAAD8UdyIiFWTRtPHS9HtddIMsqQJn8Xiweb7slevRWP4zoK+31hMkDHDAJ3IfkOB8Dj4lERFn1WxsVVLG3PC17mjPcDhXzpAjadFWWo345BHkdn3r/kiIsLPlY+jeNs2rqWN2cFsnL9AoiItXfaKF7i58TXOPMuY0k/BYRKPurh4lERZKvur42no4s0+/E4QtI7No3D/AAX0vcTJ+iqkrJfOlAiAPdhxbn3BERYWdhaDqKBjOi22ygnieYc55cnoiIs+Vy6P7pVOMtrk4JKdkD5GhzdxyyPUcnZERF1a5u1VRUsVDSdXBFMHtcWNwQ0EbDuByc4VDREQrVdOTeU2WgfJDCDFEwMw30cFrcjPI4J9qo+tbjU115khmLRHTOLI2tGw33J7yf8ABERZUEiIiwtvsdupptP2/rWl4NNE7DgCM8A7wqD0rUsFJeaVkDAxrqbJAaBvxO7kRFnguvolhZOLu15IAiYdv6yjOjKaQaljow77jUscJB+i0uBHjkfEoiLC5OkCNsWsLgxucBzef6DVAoiIuuzgOu1G08jOwf3grZ0vQtgvFGxhJHk5O/6bkREVIWjX6FlH0W0Locjro4Wuz/SJefiEREXjojjbV0dxppt42vY4Dv4gQfeAFn07Qyd7W8g4gIiIr70hMadH2Wo345BHkdn3oL6axjbN0c2ytkJMzzC4nO2SxwP1IiIqz0extl1fQsdnBL+X6DlYHEt6XXQg+Y9zYXeLeqA9+yIiyobpMp46fVcwjB8+KN7s9pLRn6l8bLXSwabuFKxkZZLxcRIOR5oG26Iiwq+txtFtpZrJQGVvHmmjOHAEZ4B3hERZCznpRpoaXUjIoGBrfJmHAAG+XdynuiWmjqLRXiTOBO3l4tKIiKQ6QrZR0+kqyaKFjXtMeCGNH447gqX0awRz6sp2yA+bHI4YPIhpREReuv5ZI9ZVQY9w8ncxsR7WgNBHx3Vk6VqWIWS3VeD1rpSM52AcwOI94RERV7o4lLL+YuBjhNC5riRuAMHb3Kw6qulTb7P/ALm2KF0pxxMbgtzgkjHbud0REX//2Q==";

// ── FIREBASE + LOCAL STORAGE ─────────────────────────────────────────────────
// Paste your Firebase Realtime Database URL here after creating the project
// Example: "https://doctor-parrilla-default-rtdb.firebaseio.com"
const FIREBASE_URL = "https://doctor-parrilla-clientes-default-rtdb.firebaseio.com";  // <-- PEGAR URL DE FIREBASE ACÁ

const appStorage = {
  async get(key) {
    // 1. Try Firebase
    if (FIREBASE_URL) {
      try {
        const r = await fetch(`${FIREBASE_URL}/drparrilla/${key}.json`);
        if (r.ok) { const d = await r.json(); if (d !== null) return JSON.stringify(d); }
      } catch(e) {}
    }
    // 2. Try Claude artifact storage
    try {
      if (window.storage) { const r = await window.storage.get(key); return r ? r.value : null; }
    } catch(e) {}
    // 3. Fallback localStorage
    try { return localStorage.getItem(key); } catch(e) { return null; }
  },
  async set(key, value) {
    // 1. Save to Firebase
    if (FIREBASE_URL) {
      try {
        await fetch(`${FIREBASE_URL}/drparrilla/${key}.json`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: value
        });
      } catch(e) {}
    }
    // 2. Save to Claude artifact storage
    try { if (window.storage) { await window.storage.set(key, value); } } catch(e) {}
    // 3. Save to localStorage (backup)
    try { localStorage.setItem(key, value); } catch(e) {}
  }
};

// Firebase connection status
async function checkFirebase() {
  if (!FIREBASE_URL) return false;
  try {
    const r = await fetch(`${FIREBASE_URL}/.json?shallow=true`, { signal: AbortSignal.timeout(3000) });
    return r.ok;
  } catch(e) { return false; }
}


const ADMIN_USERS = [
  { phone: "0991935364", nombre: "Samuel García", rol: "CEO" },
  { phone: "0981707549", nombre: "Jorge",          rol: "Gerente General" },
  { phone: "0992369143", nombre: "David",          rol: "Jefe de Producción" },
  { phone: "0982234753", nombre: "Dalila García",    rol: "Presidente" },
];

function normalizePhone(p) { return p.replace(/[\s\-().]/g, ""); }
function findAdmin(phone)   { const c = normalizePhone(phone); return ADMIN_USERS.find(u => normalizePhone(u.phone) === c) || null; }
function findCliente(phone, clientes) { const c = normalizePhone(phone); return clientes.find(u => normalizePhone(u.tel) === c) || null; }

// ── DÍAS HÁBILES ──────────────────────────────────────────────────────────────
const MESES = { Ene:0,Feb:1,Mar:2,Abr:3,May:4,Jun:5,Jul:6,Ago:7,Sep:8,Oct:9,Nov:10,Dic:11 };
const MESES_NOMBRE = ["Ene","Feb","Mar","Abr","May","Jun","Jul","Ago","Sep","Oct","Nov","Dic"];

function parseFecha(str) {
  // "05 Abr 2026"
  if (!str) return null;
  const p = str.trim().split(" ");
  if (p.length < 3) return null;
  const d = parseInt(p[0]); const m = MESES[p[1]]; const y = parseInt(p[2]);
  if (isNaN(d)||isNaN(y)||m===undefined) return null;
  return new Date(y, m, d);
}

function addDiasHabiles(fechaBase, dias) {
  const d = new Date(fechaBase);
  let added = 0;
  while (added < dias) {
    d.setDate(d.getDate() + 1);
    const dow = d.getDay();
    if (dow !== 0 && dow !== 6) added++;
  }
  return d;
}

function diasHabilesRestantes(fechaLimite) {
  if (!fechaLimite) return null;
  const hoy = new Date(); hoy.setHours(0,0,0,0);
  const lim = new Date(fechaLimite); lim.setHours(0,0,0,0);
  if (hoy.getTime() === lim.getTime()) return 0;
  if (hoy > lim) {
    let neg = 0; let c = new Date(lim);
    while (c < hoy) { c.setDate(c.getDate()+1); const dw=c.getDay(); if(dw!==0&&dw!==6) neg++; }
    return -neg;
  }
  let cnt = 0; let c = new Date(hoy);
  while (c < lim) { c.setDate(c.getDate()+1); const dw=c.getDay(); if(dw!==0&&dw!==6) cnt++; }
  return cnt;
}

function formatFechaCorta(date) {
  if (!date) return "—";
  return `${String(date.getDate()).padStart(2,"0")} ${MESES_NOMBRE[date.getMonth()]} ${date.getFullYear()}`;
}

function getAlertaColor(dias) {
  if (dias === null) return null;
  if (dias <= 0) return "#E53935";
  if (dias <= 3) return "#E53935";
  if (dias <= 7) return GOLD;
  return "#4CAF50";
}

function CountdownBadge({ fecha, diasHabiles, size = "normal" }) {
  const base = parseFecha(fecha);
  if (!base || !diasHabiles) return null;
  const lim = addDiasHabiles(base, diasHabiles);
  const dias = diasHabilesRestantes(lim);
  if (dias === null) return null;
  const color = getAlertaColor(dias);
  const icon  = dias <= 0 ? "🚨" : dias <= 3 ? "🔴" : dias <= 7 ? "🟡" : "🟢";
  const label = dias <= 0 ? `Vencido (${Math.abs(dias)}d)` : dias === 0 ? "¡Hoy!" : `${dias} días háb.`;
  if (size === "small") return (
    <span style={{ background:color+"22", border:`1px solid ${color}55`, color, fontSize:10, padding:"2px 8px", borderRadius:20, fontFamily:"sans-serif", fontWeight:"bold" }}>
      {icon} {label}
    </span>
  );
  return (
    <div style={{ background:color+"15", border:`1px solid ${color}44`, borderRadius:10, padding:"12px 16px", display:"flex", alignItems:"center", justifyContent:"space-between" }}>
      <div>
        <div style={{ fontSize:10, color:color, fontFamily:"sans-serif", letterSpacing:"2px", marginBottom:4 }}>DÍAS HÁBILES RESTANTES</div>
        <div style={{ fontSize:26, fontWeight:"bold", color, lineHeight:1 }}>{dias <= 0 ? "VENCIDO" : dias}</div>
        <div style={{ fontSize:11, color:"#888", fontFamily:"sans-serif", marginTop:4 }}>
          {dias > 0 ? `${icon} Entrega: ${formatFechaCorta(lim)}` : `${icon} Venció: ${formatFechaCorta(lim)}`}
        </div>
      </div>
      <div style={{ fontSize:36 }}>{dias <= 0 ? "🚨" : dias <= 3 ? "🔴" : dias <= 7 ? "⏳" : "📅"}</div>
    </div>
  );
}

function AlertaBanner({ pedidos }) {
  const urgentes = pedidos.filter(p => {
    if (p.estado === 4) return false;
    const base = parseFecha(p.fecha);
    if (!base || !p.diasHabiles) return false;
    const lim = addDiasHabiles(base, p.diasHabiles);
    const dias = diasHabilesRestantes(lim);
    return dias !== null && dias <= 7;
  });
  if (urgentes.length === 0) return null;
  return (
    <div style={{ margin:"16px 16px 0", display:"flex", flexDirection:"column", gap:8 }}>
      <div style={{ fontSize:11, color:"#E53935", fontFamily:"sans-serif", letterSpacing:"2px", fontWeight:"bold" }}>⚠️ ALERTAS DE ENTREGA</div>
      {urgentes.map(p => {
        const base = parseFecha(p.fecha);
        const lim = addDiasHabiles(base, p.diasHabiles);
        const dias = diasHabilesRestantes(lim);
        const color = getAlertaColor(dias);
        return (
          <div key={p.id} style={{ background:color+"15", border:`1px solid ${color}44`, borderRadius:10, padding:"10px 14px", display:"flex", alignItems:"center", gap:10 }}>
            <span style={{ fontSize:20 }}>{dias <= 0 ? "🚨" : dias <= 3 ? "🔴" : "🟡"}</span>
            <div style={{ flex:1 }}>
              <div style={{ fontSize:13, fontWeight:"bold", color:"#F0F0F0" }}>{p.id} · {p.modelo}</div>
              <div style={{ fontSize:11, color:"#888", fontFamily:"sans-serif", marginTop:2 }}>
                {dias <= 0 ? `Vencido hace ${Math.abs(dias)} días hábiles` : `${dias} días hábiles restantes · Entrega: ${formatFechaCorta(lim)}`}
              </div>
            </div>
            <div style={{ fontSize:18, fontWeight:"bold", color }}>{dias <= 0 ? "!" : dias}</div>
          </div>
        );
      })}
    </div>
  );
}

// ── INITIAL DATA ──────────────────────────────────────────────────────────────
const ESTADO_LABELS = ["Pedido recibido","En producción","Control de calidad","Listo para entrega","Entregado"];
const ESTADO_ICONS  = ["📋","⚙️","🔍","📦","✅"];
const ESTADO_COLORS = ["#888", GOLD, "#E8C97A", "#4CAF50", "#4CAF50"];

const INITIAL_PRODUCTOS = [
  { id:1, nombre:"El Patrón 900",     desc:"Parrilla fija premium en acero inoxidable 304. Quemadores de alta potencia, sistema de extracción de grasas.", precio:"Gs. 4.200.000",  specs:["Acero inox 304","90cm ancho","Para 8-10 personas","3mm espesor"],  colores:["Grill","Negro"], foto:null, tag:"MÁS VENDIDO", emoji:"🔥" },
  { id:2, nombre:"Josephine Portable",desc:"Parrilla portátil diseñada para eventos y espacios reducidos. Plegable y resistente.",                         precio:"Gs. 1.800.000",  specs:["Acero inox 201","60cm ancho","Para 4-6 personas","Plegable"],        colores:["Grill"],         foto:null, tag:"PORTÁTIL",    emoji:"⚡" },
  { id:3, nombre:"Viking Pro 1200",   desc:"Parrilla profesional para quinchos y restaurantes. La preferida por chefs y asadores profesionales.",           precio:"Gs. 8.500.000",  specs:["Acero inox 316","120cm ancho","Para 15+ personas","Uso comercial"], colores:["Grill","Negro"], foto:null, tag:"PRO",         emoji:"👑" },
  { id:4, nombre:"Quincho Master",    desc:"Sistema completo de quincho con parrilla, mesada y módulos de almacenamiento. Todo integrado.",                 precio:"Gs. 15.000.000", specs:["Acero inox 304","Modular","Personalizable","Incluye instalación"],  colores:["Negro"],         foto:null, tag:"PREMIUM",     emoji:"🏆" },
];

const INITIAL_CLIENTES = [
  { id:"C-001", codigo:"CLI-001", nombre:"Carlos Rodríguez", tel:"0981234567", dir:"Av. Mcal. López 1234, Lambaré",  historial:"Cliente desde 2023. Compró El Patrón 900. Prefiere entrega a domicilio." },
  { id:"C-002", codigo:"CLI-002", nombre:"Ana Martínez",     tel:"0991876543", dir:"Gral. Genes 567, Asunción",      historial:"Empresaria. Restaurante en el centro. Interesada en mantenimiento anual." },
  { id:"C-003", codigo:"CLI-003", nombre:"Roberto Silva",    tel:"0976111222", dir:"Ruta 1 km 18, San Lorenzo",      historial:"" },
];

const ESTADO_NEURO = [
  "Tu pedido está en nuestras manos. Los mejores artesanos del acero ya conocen tu nombre.",
  "Manos expertas forjan tu parrilla ahora mismo. Cada corte, cada soldadura - hecho para toda la vida.",
  "Tu parrilla paso por control de calidad. Solo lo perfecto llega a tu hogar.",
  "Tu parrilla de ensueño esta lista! Pronto el aroma del asado llenara tu espacio.",
  "Bienvenida a tu familia. Que cada asado sea un recuerdo imborrable.",
];


const INITIAL_PEDIDOS = [
  { id:"DP-2024-089", tel:"0981234567", modelo:"El Patrón 900",      fecha:"28 Mar 2026", estado:3, monto:"Gs. 4.200.000", nota:"Entrega a domicilio Lambaré", fotos:[], diasHabiles:10 },
  { id:"DP-2024-072", tel:"0991876543", modelo:"Viking Pro 1200",    fecha:"10 Feb 2026", estado:4, monto:"Gs. 8.500.000", nota:"Retira en taller",            fotos:[], diasHabiles:10 },
  { id:"DP-2024-101", tel:"0976111222", modelo:"Josephine Portable", fecha:"05 Abr 2026", estado:1, monto:"Gs. 1.800.000", nota:"",                            fotos:[], diasHabiles:10 },
];

const INITIAL_TICKETS = [
  { id:"T-045", tel:"0981234567", tipo:"Mantenimiento", desc:"Limpieza anual y revisión de soldaduras",                                      fecha:"01 Abr 2026", estado:"En proceso" },
  { id:"T-031", tel:"0991876543", tipo:"Consulta",      desc:"Consulta sobre accesorios adicionales para Viking Pro",                        fecha:"15 Mar 2026", estado:"Resuelto"   },
  { id:"T-038", tel:"0976111222", tipo:"Reclamo",       desc:"La parrilla tiene una soldadura que se está levantando en el borde izquierdo", fecha:"03 Abr 2026", estado:"Abierto"    },
];

// ── LOGO COMPONENT ───────────────────────────────────────────────────────────
function Logo({ width = 160, style = {} }) {
  return (
    <img
      src={LOGO_B64}
      alt="Dr. Parrilla"
      style={{ width, height: "auto", display: "block", ...style }}
    />
  );
}


// ── HELPERS ───────────────────────────────────────────────────────────────────
function Tag({ label, color = GOLD }) {
  return <span style={{ background:color+"22", border:`1px solid ${color}55`, color, fontSize:9, padding:"2px 8px", borderRadius:20, fontFamily:"sans-serif", letterSpacing:"1.5px", fontWeight:"bold" }}>{label}</span>;
}
function Header({ title, subtitle, back, onBack }) {
  return (
    <div style={{ padding:"20px 20px 16px", borderBottom:`1px solid ${BORDER}`, display:"flex", alignItems:"center", gap:12 }}>
      {back && <button onClick={onBack} style={{ background:"none", border:"none", color:GOLD, fontSize:22, cursor:"pointer", padding:"0 4px 0 0" }}>←</button>}
      <div>
        <div style={{ fontSize:10, color:GOLD, fontFamily:"sans-serif", letterSpacing:"3px", textTransform:"uppercase", marginBottom:2 }}>{subtitle||"DOCTOR PARRILLA"}</div>
        <div style={{ fontSize:20, fontWeight:"bold" }}>{title}</div>
      </div>
    </div>
  );
}
function BottomNav({ active, setActive, isAdmin }) {
  const items = isAdmin
    ? [{ key:"admin-orders",label:"Pedidos",icon:"📦" },{ key:"admin-tickets",label:"Soporte",icon:"🔧" },{ key:"admin-clientes",label:"Clientes",icon:"👥" },{ key:"admin-resenas",label:"Resenas",icon:"⭐" },{ key:"admin-catalog",label:"Catalogo",icon:"🔥" }]
    : [{ key:"home",label:"Inicio",icon:"⌂" },{ key:"catalogo",label:"Catálogo",icon:"🔥" },{ key:"pedidos",label:"Pedidos",icon:"📦" },{ key:"soporte",label:"Soporte",icon:"🔧" }];
  return (
    <div style={{ position:"fixed", bottom:0, left:"50%", transform:"translateX(-50%)", width:"100%", maxWidth:430, background:"#0D0D0D", borderTop:`1px solid ${BORDER}`, display:"flex", zIndex:100 }}>
      {items.map(it => (
        <button key={it.key} onClick={() => setActive(it.key)} style={{ flex:1, padding:"12px 0 10px", background:"none", border:"none", cursor:"pointer", display:"flex", flexDirection:"column", alignItems:"center", gap:3, opacity:active===it.key?1:0.45 }}>
          <span style={{ fontSize:20 }}>{it.icon}</span>
          <span style={{ fontSize:10, color:active===it.key?GOLD:"#888", fontFamily:"sans-serif", letterSpacing:"0.5px", textTransform:"uppercase" }}>{it.label}</span>
          {active===it.key && <div style={{ width:20, height:2, background:GOLD, borderRadius:1, marginTop:2 }} />}
        </button>
      ))}
    </div>
  );
}

function PhotoUploadButton({ onPhoto, label = "📷 Subir foto", style = {} }) {
  const ref = useRef();
  const handle = (e) => {
    const file = e.target.files[0]; if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => onPhoto(ev.target.result);
    reader.readAsDataURL(file); e.target.value = "";
  };
  return (
    <>
      <input type="file" accept="image/*" ref={ref} onChange={handle} style={{ display:"none" }} />
      <button onClick={() => ref.current?.click()} style={{ background:CARD, border:`1px solid ${BORDER}`, color:"#CCC", padding:"12px 16px", borderRadius:10, fontFamily:"sans-serif", fontSize:13, cursor:"pointer", display:"flex", alignItems:"center", gap:8, ...style }}>{label}</button>
    </>
  );
}

// ── REVIEW COMPONENT ─────────────────────────────────────────────────────────
function ReviewFlow({ pedido, onSave, onClose }) {
  const [step, setStep] = useState(1); // 1=stars, 2=comment, 3=done
  const [stars, setStars] = useState(0);
  const [comment, setComment] = useState("");

  const submit = () => {
    if (stars === 0) return;
    onSave({ stars, comment, fecha: new Date().toLocaleDateString("es-PY",{day:"2-digit",month:"short",year:"numeric"}) });
    setStep(3);
  };

  if (step === 3) return (
    <div style={{ background:CARD, border:`1px solid ${GOLD}44`, borderRadius:16, padding:24, textAlign:"center" }}>
      <div style={{ fontSize:48, marginBottom:12 }}>🎉</div>
      <div style={{ fontSize:20, fontWeight:"bold", marginBottom:8 }}>¡Gracias por tu reseña!</div>
      <div style={{ fontSize:13, color:"#888", fontFamily:"sans-serif", marginBottom:24, lineHeight:1.6 }}>
        Tu opinión nos ayuda a mejorar y a que más familias disfruten de una parrilla Dr. Parrilla.
      </div>
      <div style={{ fontSize:13, color:"#AAA", fontFamily:"sans-serif", marginBottom:16 }}>
        ¿Podés compartir tu experiencia en Google? Solo toma 30 segundos y ayuda muchísimo al negocio 🙏
      </div>
      <a href={GOOGLE_REVIEW_URL} target="_blank" rel="noreferrer"
        style={{ display:"block", width:"100%", background:"linear-gradient(135deg,#4285F4,#34A853)", border:"none", color:"#FFF", padding:"14px", borderRadius:10, fontSize:15, fontFamily:"sans-serif", fontWeight:"bold", cursor:"pointer", textDecoration:"none", textAlign:"center", boxSizing:"border-box", marginBottom:10 }}>
        ⭐ Dejar reseña en Google
      </a>
      <button onClick={onClose} style={{ width:"100%", background:"none", border:`1px solid ${BORDER}`, color:"#888", padding:"12px", borderRadius:10, fontSize:14, fontFamily:"sans-serif", cursor:"pointer" }}>
        Cerrar
      </button>
    </div>
  );

  if (step === 2) return (
    <div style={{ background:CARD, border:`1px solid ${GOLD}44`, borderRadius:16, padding:20 }}>
      <div style={{ display:"flex", justifyContent:"center", gap:6, marginBottom:12 }}>
        {[1,2,3,4,5].map(s => <span key={s} style={{ fontSize:28 }}>{s<=stars?"⭐":"☆"}</span>)}
      </div>
      <div style={{ fontSize:14, fontWeight:"bold", marginBottom:14, textAlign:"center" }}>
        {stars>=4?"¡Nos alegra mucho! Contanos más:":"¿Cómo podemos mejorar?"}
      </div>
      <textarea value={comment} onChange={e=>setComment(e.target.value)}
        placeholder="Contá tu experiencia con la parrilla, el servicio, la entrega..."
        style={{ width:"100%", height:100, background:DARK3, border:`1px solid ${BORDER}`, color:"#F0F0F0", padding:"12px", borderRadius:10, fontSize:14, fontFamily:"sans-serif", outline:"none", resize:"none", boxSizing:"border-box", marginBottom:14 }}/>
      <button onClick={submit}
        style={{ width:"100%", background:`linear-gradient(135deg,${GOLD},${GOLD_LIGHT})`, border:"none", color:DARK, padding:"14px", borderRadius:10, fontSize:14, fontFamily:"sans-serif", fontWeight:"bold", cursor:"pointer", marginBottom:8 }}>
        ENVIAR RESEÑA
      </button>
      <button onClick={() => setStep(1)} style={{ width:"100%", background:"none", border:"none", color:"#888", padding:"8px", fontSize:13, fontFamily:"sans-serif", cursor:"pointer" }}>← Volver</button>
    </div>
  );

  // Step 1: Stars
  const labels = ["","Malo","Regular","Bueno","Muy bueno","Excelente"];
  return (
    <div style={{ background:CARD, border:`1px solid ${GOLD}44`, borderRadius:16, padding:20, textAlign:"center" }}>
      <div style={{ fontSize:36, marginBottom:8 }}>🔥</div>
      <div style={{ fontSize:18, fontWeight:"bold", marginBottom:4 }}>¡Tu parrilla fue entregada!</div>
      <div style={{ fontSize:13, color:"#888", fontFamily:"sans-serif", marginBottom:20 }}>¿Cómo fue tu experiencia con Dr. Parrilla?</div>
      <div style={{ display:"flex", justifyContent:"center", gap:8, marginBottom:8 }}>
        {[1,2,3,4,5].map(s => (
          <button key={s} onClick={() => setStars(s)}
            style={{ background:"none", border:"none", cursor:"pointer", fontSize:36, transform: s<=stars?"scale(1.2)":"scale(1)", transition:"transform 0.1s" }}>
            {s<=stars?"⭐":"☆"}
          </button>
        ))}
      </div>
      {stars>0 && <div style={{ fontSize:14, color:GOLD, fontFamily:"sans-serif", marginBottom:16, fontWeight:"bold" }}>{labels[stars]}</div>}
      <button onClick={() => stars>0&&setStep(2)} disabled={stars===0}
        style={{ width:"100%", background:stars>0?`linear-gradient(135deg,${GOLD},${GOLD_LIGHT})`:BORDER, border:"none", color:stars>0?DARK:"#555", padding:"14px", borderRadius:10, fontSize:14, fontFamily:"sans-serif", fontWeight:"bold", cursor:stars>0?"pointer":"default", marginBottom:8 }}>
        CONTINUAR
      </button>
      <button onClick={onClose} style={{ background:"none", border:"none", color:"#555", fontSize:12, fontFamily:"sans-serif", cursor:"pointer" }}>Ahora no</button>
    </div>
  );
}


// ── CELEBRATION COMPONENT ────────────────────────────────────────────────────
function CelebrationBanner({ modelo, onClose }) {
  return (
    <div style={{ background:"linear-gradient(135deg,#1A0D00,#0A0A0A)", border:`2px solid ${GOLD}`, borderRadius:16, padding:24, textAlign:"center", marginBottom:20, position:"relative" }}>
      <div style={{ fontSize:48, marginBottom:8 }}>🎉</div>
      <div style={{ fontSize:20, fontWeight:"bold", color:GOLD, marginBottom:6 }}>¡Tu parrilla está lista!</div>
      <div style={{ fontSize:14, color:"#CCC", fontFamily:"sans-serif", marginBottom:4, lineHeight:1.6 }}>
        El equipo de Dr. Parrilla terminó tu <strong>{modelo}</strong>.<br/>
        Pronto coordinaremos la entrega.
      </div>
      <div style={{ fontSize:12, color:"#888", fontFamily:"sans-serif", marginTop:8, fontStyle:"italic" }}>
        "El fuego perfecto te espera 🔥"
      </div>
      <button onClick={onClose} style={{ position:"absolute", top:10, right:12, background:"none", border:"none", color:"#555", fontSize:18, cursor:"pointer" }}>✕</button>
    </div>
  );
}

// ── TIPS WHILE WAITING ────────────────────────────────────────────────────────
const TIPS = [
  { icon:"🔥", titulo:"El primer fuego", texto:"Antes de usar tu parrilla, hacé un fuego de inicialización para curar la superficie. Esto potencia el sabor." },
  { icon:"🧂", titulo:"El secreto de la sal", texto:"Salá la carne gruesa 45 minutos antes de poner al fuego. La sal sella los jugos por dentro." },
  { icon:"🪵", titulo:"Madera correcta", texto:"Usá quebracho o algarrobo. Generan brasas duraderas y aromáticas, perfectas para asados largos." },
  { icon:"🌡️", titulo:"La temperatura ideal", texto:"Para vacío y costillas: fuego bajo 3+ horas. Para lomo y solomillo: fuego fuerte 8-10 minutos por lado." },
  { icon:"🫗", titulo:"No pinches la carne", texto:"Usá pinzas, nunca tenedor. Pinchar deja salir los jugos y la carne queda seca." },
];

function TipsSection() {
  const [tipIdx, setTipIdx] = React.useState(0);
  const tip = TIPS[tipIdx];
  return (
    <div style={{ background:CARD, border:`1px solid ${BORDER}`, borderRadius:12, padding:"16px", marginBottom:16 }}>
      <div style={{ fontSize:10, color:GOLD, fontFamily:"sans-serif", letterSpacing:"2px", marginBottom:12 }}>🔥 MIENTRAS ESPERAS — TIPS DEL ASADOR</div>
      <div style={{ display:"flex", gap:12, alignItems:"flex-start", marginBottom:14 }}>
        <span style={{ fontSize:28, flexShrink:0 }}>{tip.icon}</span>
        <div>
          <div style={{ fontSize:15, fontWeight:"bold", marginBottom:4 }}>{tip.titulo}</div>
          <div style={{ fontSize:13, color:"#AAA", fontFamily:"sans-serif", lineHeight:1.6 }}>{tip.texto}</div>
        </div>
      </div>
      <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center" }}>
        <div style={{ display:"flex", gap:6 }}>
          {TIPS.map((_,i) => <div key={i} onClick={() => setTipIdx(i)} style={{ width:i===tipIdx?20:6, height:6, borderRadius:3, background:i===tipIdx?GOLD:BORDER, cursor:"pointer", transition:"width 0.2s" }}/>)}
        </div>
        <button onClick={() => setTipIdx((tipIdx+1)%TIPS.length)} style={{ background:GOLD+"22", border:`1px solid ${GOLD}44`, color:GOLD, padding:"6px 14px", borderRadius:20, fontSize:12, fontFamily:"sans-serif", cursor:"pointer" }}>
          Siguiente →
        </button>
      </div>
    </div>
  );
}


// ── LOGIN ─────────────────────────────────────────────────────────────────────
function LoginScreen({ onLogin, clientes }) {
  const [mode, setMode] = useState("cliente"); // "cliente" o "admin"
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  
  const adminMatch   = mode === "cliente" ? findAdmin(phone) : null;
  const clienteMatch = mode === "cliente" && !adminMatch ? findCliente(phone, clientes) : null;
  const known = adminMatch || clienteMatch;
  
  const handleAdminLogin = () => {
    if (password === ADMIN_PASSWORD) {
      const selectedAdmin = ADMINS[0]; // Por defecto el primer admin
      onLogin(selectedAdmin, null, true);
    } else {
      alert("❌ Contraseña incorrecta");
    }
  };
  
  return (
    <div style={{ minHeight:"100vh", background:DARK, display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", padding:32 }}>
      <div style={{ marginBottom:12, filter:"drop-shadow(0 0 28px #C9A84C33)" }}>
        <Logo width={200} />
      </div>
      <div style={{ fontSize:13, color:"#777", fontFamily:"sans-serif", fontStyle:"italic", marginBottom:32, textAlign:"center" }}>
        "La parrilla de tus suenos esta en camino"
      </div>
      
      {/* Tabs: Cliente vs Admin */}
      <div style={{ display:"flex", gap:8, marginBottom:24, background:CARD, padding:8, borderRadius:8, border:`1px solid ${BORDER}` }}>
        <button onClick={() => { setMode("cliente"); setPassword(""); }} 
          style={{ flex:1, padding:"10px 16px", background:mode==="cliente"?GOLD:"transparent", color:mode==="cliente"?DARK:"#999", border:"none", borderRadius:6, fontFamily:"sans-serif", fontWeight:"bold", cursor:"pointer" }}>👤 CLIENTE</button>
        <button onClick={() => { setMode("admin"); setPhone(""); }} 
          style={{ flex:1, padding:"10px 16px", background:mode==="admin"?GOLD:"transparent", color:mode==="admin"?DARK:"#999", border:"none", borderRadius:6, fontFamily:"sans-serif", fontWeight:"bold", cursor:"pointer" }}>🔑 ADMIN</button>
      </div>
      
      <div style={{ width:"100%", maxWidth:340 }}>
        {mode === "cliente" ? (
          <>
            <div style={{ fontSize:11, color:"#888", fontFamily:"sans-serif", letterSpacing:"1px", marginBottom:8 }}>TU NÚMERO DE TELÉFONO</div>
            <input type="tel" placeholder="09XX XXX XXX" value={phone} onChange={e => setPhone(e.target.value)}
              onKeyDown={e => e.key==="Enter" && phone.length>4 && onLogin(adminMatch, clienteMatch, !!adminMatch)}
              style={{ width:"100%", background:CARD, border:`1px solid ${known?GOLD:BORDER}`, color:"#F0F0F0", padding:"14px 16px", borderRadius:8, fontSize:16, fontFamily:"sans-serif", outline:"none", boxSizing:"border-box", marginBottom:8 }} />
            {known && (
              <div style={{ background:`${GOLD}11`, border:`1px solid ${GOLD}44`, borderRadius:8, padding:"10px 14px", marginBottom:12, display:"flex", alignItems:"center", gap:10 }}>
                <span style={{ fontSize:22 }}>👤</span>
                <div>
                  <div style={{ fontSize:13, fontWeight:"bold", color:GOLD }}>{clienteMatch.nombre}</div>
                  <div style={{ fontSize:11, color:"#999", fontFamily:"sans-serif" }}>Cliente registrado</div>
                </div>
              </div>
            )}
            <button onClick={() => phone.length>4 && onLogin(adminMatch, clienteMatch, !!adminMatch)}
              style={{ width:"100%", background:phone.length>4?`linear-gradient(135deg,${GOLD},${GOLD_LIGHT})`:BORDER, border:"none", color:phone.length>4?DARK:"#555", padding:"16px", borderRadius:8, fontSize:15, fontFamily:"sans-serif", fontWeight:"bold", letterSpacing:"2px", cursor:phone.length>4?"pointer":"default" }}>
              INGRESAR
            </button>
          </>
        ) : (
          <>
            <div style={{ fontSize:11, color:"#888", fontFamily:"sans-serif", letterSpacing:"1px", marginBottom:8 }}>🔑 CONTRASEÑA DE ADMINISTRADOR</div>
            <input type="password" placeholder="Ingresa la contraseña" value={password} onChange={e => setPassword(e.target.value)}
              onKeyDown={e => e.key==="Enter" && password.length>0 && handleAdminLogin()}
              style={{ width:"100%", background:CARD, border:`1px solid ${BORDER}`, color:"#F0F0F0", padding:"14px 16px", borderRadius:8, fontSize:16, fontFamily:"sans-serif", outline:"none", boxSizing:"border-box", marginBottom:8 }} />
            {password === ADMIN_PASSWORD && (
              <div style={{ background:`${GOLD}11`, border:`1px solid ${GOLD}44`, borderRadius:8, padding:"10px 14px", marginBottom:12, display:"flex", alignItems:"center", gap:10 }}>
                <span style={{ fontSize:22 }}>✅</span>
                <div>
                  <div style={{ fontSize:13, fontWeight:"bold", color:GOLD }}>Contraseña correcta</div>
                  <div style={{ fontSize:11, color:"#999", fontFamily:"sans-serif" }}>Acceso de administrador</div>
                </div>
              </div>
            )}
            <button onClick={handleAdminLogin}
              style={{ width:"100%", background:password.length>0?`linear-gradient(135deg,${GOLD},${GOLD_LIGHT})`:BORDER, border:"none", color:password.length>0?DARK:"#555", padding:"16px", borderRadius:8, fontSize:15, fontFamily:"sans-serif", fontWeight:"bold", letterSpacing:"2px", cursor:password.length>0?"pointer":"default" }}>
              🔑 ACCESO ADMIN
            </button>
          </>
        )}
      </div>
    </div>
  );
}

// ── CLIENT: HOME ──────────────────────────────────────────────────────────────
function HomeScreen({ setActive, clienteUser, pedidos }) {
  const nombre = clienteUser?.nombre?.split(" ")[0] || "";
  const misPedidos = clienteUser ? pedidos.filter(p => normalizePhone(p.tel)===normalizePhone(clienteUser.tel) && p.estado < 4) : [];
  const urgente = misPedidos.find(p => {
    const base = parseFecha(p.fecha); if (!base||!p.diasHabiles) return false;
    const lim = addDiasHabiles(base, p.diasHabiles);
    const d = diasHabilesRestantes(lim);
    return d !== null && d <= 7;
  });
  return (
    <div style={{ paddingBottom:80 }}>
      <div style={{ padding:"28px 20px 24px", background:"linear-gradient(180deg, #1A1200 0%, #0A0A0A 100%)", borderBottom:`1px solid ${BORDER}` }}>
        <Logo width={100} style={{ marginBottom:14 }} />
        <div style={{ fontSize:10, color:GOLD, fontFamily:"sans-serif", letterSpacing:"3px", marginBottom:6 }}>BIENVENIDO</div>
        <div style={{ fontSize:24, fontWeight:"bold", marginBottom:4 }}>Hola, {nombre} 👋</div>
        <div style={{ fontSize:13, color:"#666", fontFamily:"sans-serif" }}>¿Qué necesitás hoy?</div>
      </div>
      {urgente && (() => {
        const base = parseFecha(urgente.fecha);
        const lim = addDiasHabiles(base, urgente.diasHabiles);
        const dias = diasHabilesRestantes(lim);
        const color = getAlertaColor(dias);
        return (
          <div style={{ margin:"16px 16px 0", background:color+"15", border:`1px solid ${color}44`, borderRadius:10, padding:"14px 16px", display:"flex", alignItems:"center", gap:12 }}>
            <span style={{ fontSize:24 }}>{dias<=0?"🚨":dias<=3?"🔴":"⏳"}</span>
            <div style={{ flex:1 }}>
              <div style={{ fontSize:12, color, fontFamily:"sans-serif", fontWeight:"bold" }}>
                {dias<=0?"PEDIDO VENCIDO":`${dias} DÍAS HÁBILES PARA ENTREGA`}
              </div>
              <div style={{ fontSize:12, color:"#AAA", fontFamily:"sans-serif", marginTop:2 }}>{urgente.id} · {urgente.modelo}</div>
            </div>
            <button onClick={() => setActive("pedidos")} style={{ background:color, border:"none", color:DARK, fontSize:11, padding:"6px 12px", borderRadius:20, fontFamily:"sans-serif", fontWeight:"bold", cursor:"pointer", flexShrink:0 }}>VER</button>
          </div>
        );
      })()}
      <div style={{ padding:"16px 20px 0", display:"flex", flexDirection:"column", gap:12 }}>
        {[{key:"catalogo",icon:"🔥",title:"Catálogo",desc:"Explorá todos nuestros modelos"},
          {key:"pedidos",icon:"📦",title:"Mis Pedidos",desc: misPedidos.length > 0 ? `${misPedidos.length} pedido${misPedidos.length>1?"s":""} activo${misPedidos.length>1?"s":""}` : "Seguí el estado de tu pedido"},
          {key:"soporte",icon:"🔧",title:"Soporte",desc:"Reclamos y mantenimiento"}
        ].map(c => (
          <button key={c.key} onClick={() => setActive(c.key)} style={{ background:CARD, border:`1px solid ${BORDER}`, borderRadius:12, padding:"20px", display:"flex", alignItems:"center", gap:16, cursor:"pointer", textAlign:"left" }}>
            <div style={{ width:52, height:52, background:GOLD+"18", borderRadius:14, display:"flex", alignItems:"center", justifyContent:"center", fontSize:26, border:`1px solid ${GOLD}33`, flexShrink:0 }}>{c.icon}</div>
            <div><div style={{ fontSize:17, fontWeight:"bold", marginBottom:3 }}>{c.title}</div><div style={{ fontSize:12, color:"#666", fontFamily:"sans-serif" }}>{c.desc}</div></div>
            <span style={{ marginLeft:"auto", color:GOLD, fontSize:18 }}>›</span>
          </button>
        ))}
      </div>
      <div style={{ margin:"16px 20px 0" }}>
        <a href={`https://wa.me/${WA_NUMBER}`} target="_blank" rel="noreferrer"
          style={{ display:"flex", alignItems:"center", gap:12, background:"#0A1F0A", border:"1px solid #1A3A1A", borderRadius:12, padding:"16px 20px", textDecoration:"none" }}>
          <span style={{ fontSize:24 }}>💬</span>
          <div><div style={{ fontSize:14, fontWeight:"bold", color:"#4CAF50" }}>WhatsApp Directo</div><div style={{ fontSize:12, color:"#666", fontFamily:"sans-serif" }}>+595 994 389 932</div></div>
          <span style={{ marginLeft:"auto", color:"#4CAF50", fontSize:18 }}>›</span>
        </a>
      </div>
    </div>
  );
}

// ── CLIENT: CATÁLOGO ──────────────────────────────────────────────────────────
function CatalogoScreen({ productos }) {
  const [selected, setSelected] = useState(null);
  const [colorSel, setColorSel] = useState(null);
  const [done, setDone] = useState(false);
  if (done) return (
    <div style={{ display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", minHeight:"60vh", padding:32, textAlign:"center" }}>
      <div style={{ fontSize:60, marginBottom:16 }}>✅</div>
      <div style={{ fontSize:22, fontWeight:"bold", marginBottom:8 }}>¡Solicitud enviada!</div>
      <div style={{ fontSize:14, color:"#888", fontFamily:"sans-serif", marginBottom:28 }}>Te contactamos en menos de 24hs.</div>
      <button onClick={() => { setSelected(null); setDone(false); setColorSel(null); }} style={{ background:`linear-gradient(135deg,${GOLD},${GOLD_LIGHT})`, border:"none", color:DARK, padding:"14px 32px", borderRadius:8, fontFamily:"sans-serif", fontWeight:"bold", fontSize:14, cursor:"pointer" }}>VOLVER AL CATÁLOGO</button>
    </div>
  );
  if (selected !== null) {
    const p = productos.find(x => x.id===selected);
    const curColor = colorSel || (p.colores[0]||"");
    return (
      <div style={{ paddingBottom:100 }}>
        <Header title={p.nombre} back onBack={() => { setSelected(null); setColorSel(null); }} />
        <div style={{ height:200, background:"linear-gradient(135deg,#1A1200,#0D0D0D)", display:"flex", alignItems:"center", justifyContent:"center", overflow:"hidden" }}>
          {p.foto ? <img src={p.foto} alt={p.nombre} style={{ width:"100%", height:"100%", objectFit:"cover", opacity:0.9 }} /> : <span style={{ fontSize:88 }}>{p.emoji}</span>}
        </div>
        <div style={{ padding:"20px" }}>
          <div style={{ display:"flex", gap:8, marginBottom:12 }}><Tag label={p.tag} /></div>
          <div style={{ fontSize:22, fontWeight:"bold", marginBottom:6 }}>{p.nombre}</div>
          <div style={{ fontSize:22, color:GOLD, fontWeight:"bold", marginBottom:16 }}>{p.precio}</div>
          <div style={{ fontSize:14, color:"#AAA", fontFamily:"sans-serif", lineHeight:1.7, marginBottom:24 }}>{p.desc}</div>
          {p.colores.length > 0 && <>
            <div style={{ fontSize:11, color:GOLD, fontFamily:"sans-serif", letterSpacing:"2px", marginBottom:12 }}>COLOR / ACABADO</div>
            <div style={{ display:"flex", gap:10, marginBottom:24 }}>
              {p.colores.map(c => (
                <button key={c} onClick={() => setColorSel(c)} style={{ flex:1, padding:"12px", borderRadius:10, border:`2px solid ${curColor===c?GOLD:BORDER}`, background:curColor===c?GOLD+"18":CARD, cursor:"pointer", display:"flex", flexDirection:"column", alignItems:"center", gap:6 }}>
                  <div style={{ width:28, height:28, borderRadius:"50%", background:c==="Negro"?"#1a1a1a":"#C0C0C0", border:`2px solid ${c==="Negro"?"#444":"#888"}` }} />
                  <span style={{ fontSize:12, color:curColor===c?GOLD:"#888", fontFamily:"sans-serif", fontWeight:curColor===c?"bold":"normal" }}>{c}</span>
                </button>
              ))}
            </div>
          </>}
          <div style={{ fontSize:11, color:GOLD, fontFamily:"sans-serif", letterSpacing:"2px", marginBottom:12 }}>ESPECIFICACIONES</div>
          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:10, marginBottom:28 }}>
            {p.specs.map((s,i) => <div key={i} style={{ background:CARD, border:`1px solid ${BORDER}`, borderRadius:8, padding:"10px 14px", fontSize:13, fontFamily:"sans-serif", color:"#CCC" }}>✓ {s}</div>)}
          </div>
          <button onClick={() => setDone(true)} style={{ width:"100%", background:`linear-gradient(135deg,${GOLD},${GOLD_LIGHT})`, border:"none", color:DARK, padding:"16px", borderRadius:10, fontSize:15, fontFamily:"sans-serif", fontWeight:"bold", letterSpacing:"2px", cursor:"pointer", marginBottom:12 }}>SOLICITAR COTIZACIÓN</button>
          <a href={`https://wa.me/${WA_NUMBER}?text=Hola! Me interesa la ${p.nombre} en color ${curColor}`} target="_blank" rel="noreferrer"
            style={{ display:"block", textAlign:"center", width:"100%", background:"none", border:`1px solid ${BORDER}`, color:"#4CAF50", padding:"14px", borderRadius:10, fontSize:14, fontFamily:"sans-serif", textDecoration:"none", boxSizing:"border-box" }}>
            💬 Consultar por WhatsApp
          </a>
        </div>
      </div>
    );
  }
  return (
    <div style={{ paddingBottom:80 }}>
      <Header title="Catálogo" subtitle="NUESTROS MODELOS" />
      <div style={{ padding:"16px", display:"flex", flexDirection:"column", gap:12 }}>
        {productos.map(p => (
          <button key={p.id} onClick={() => setSelected(p.id)} style={{ background:CARD, border:`1px solid ${BORDER}`, borderRadius:12, padding:0, cursor:"pointer", textAlign:"left", overflow:"hidden" }}>
            <div style={{ height:120, background:"linear-gradient(135deg,#1A1200,#0D0D0D)", display:"flex", alignItems:"center", justifyContent:"center", borderBottom:`1px solid ${BORDER}`, overflow:"hidden" }}>
              {p.foto ? <img src={p.foto} alt={p.nombre} style={{ width:"100%", height:"100%", objectFit:"cover", opacity:0.85 }} /> : <span style={{ fontSize:60 }}>{p.emoji}</span>}
            </div>
            <div style={{ padding:"14px 16px" }}>
              <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:6 }}>
                <div style={{ fontSize:16, fontWeight:"bold" }}>{p.nombre}</div><Tag label={p.tag} />
              </div>
              <div style={{ display:"flex", gap:6, marginBottom:8 }}>
                {p.colores.map(c => <span key={c} style={{ fontSize:10, color:"#888", fontFamily:"sans-serif", background:DARK3, border:`1px solid ${BORDER}`, padding:"2px 8px", borderRadius:20 }}>{c}</span>)}
              </div>
              <div style={{ fontSize:13, color:"#666", fontFamily:"sans-serif", marginBottom:10, lineHeight:1.5 }}>{p.desc.slice(0,80)}…</div>
              <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center" }}>
                <div style={{ fontSize:17, color:GOLD, fontWeight:"bold" }}>{p.precio}</div>
                <span style={{ color:GOLD, fontSize:20 }}>›</span>
              </div>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}

// ── CLIENT: PEDIDOS ───────────────────────────────────────────────────────────
function PedidosScreen({ pedidos, setPedidos, clienteUser }) {
  const [selected, setSelected] = useState(null);
  const [reviewData, setReviewData] = useState(null);
  const [showCelebration, setShowCelebration] = useState(true);
  const misPedidos = clienteUser ? pedidos.filter(p => normalizePhone(p.tel)===normalizePhone(clienteUser.tel)) : [];
  const readyPedido = misPedidos.find(p => p.estado === 3);

  // Save review when submitted
  React.useEffect(() => {
    if (!reviewData) return;
    setPedidos(prev => prev.map(p => p.id===reviewData.pedidoId ? {...p, resena:reviewData.resena} : p));
    setReviewData(null);
  }, [reviewData]);
  if (selected !== null) {
    const p = misPedidos[selected];
    const pct = Math.round((p.estado/(ESTADO_LABELS.length-1))*100);
    const base = parseFecha(p.fecha);
    const lim = base && p.diasHabiles ? addDiasHabiles(base, p.diasHabiles) : null;
    return (
      <div style={{ paddingBottom:80 }}>
        <Header title={p.id} subtitle="DETALLE DE PEDIDO" back onBack={() => setSelected(null)} />
        <div style={{ padding:"20px" }}>
          {lim && p.estado < 4 && <div style={{ marginBottom:20 }}><CountdownBadge fecha={p.fecha} diasHabiles={p.diasHabiles} /></div>}
          <div style={{ background:CARD, border:`1px solid ${BORDER}`, borderRadius:12, padding:"16px 20px", marginBottom:20 }}>
            <div style={{ fontSize:11, color:"#555", fontFamily:"sans-serif", marginBottom:4 }}>MODELO</div>
            <div style={{ fontSize:20, fontWeight:"bold", marginBottom:14 }}>{p.modelo}</div>
            <div style={{ height:1, background:BORDER, marginBottom:14 }} />
            <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:12 }}>
              <div><div style={{ fontSize:10, color:"#555", fontFamily:"sans-serif", marginBottom:3 }}>FECHA PEDIDO</div><div style={{ fontSize:13, color:"#CCC", fontFamily:"sans-serif" }}>{p.fecha}</div></div>
              <div><div style={{ fontSize:10, color:"#555", fontFamily:"sans-serif", marginBottom:3 }}>MONTO</div><div style={{ fontSize:15, color:GOLD, fontWeight:"bold" }}>{p.monto}</div></div>
            </div>
            {lim && <><div style={{ height:1, background:BORDER, margin:"12px 0" }} /><div style={{ display:"flex", justifyContent:"space-between" }}><div><div style={{ fontSize:10, color:"#555", fontFamily:"sans-serif", marginBottom:3 }}>DÍAS HÁBILES ASIGNADOS</div><div style={{ fontSize:13, color:"#CCC", fontFamily:"sans-serif" }}>{p.diasHabiles} días (Lun–Vie)</div></div><div><div style={{ fontSize:10, color:"#555", fontFamily:"sans-serif", marginBottom:3 }}>FECHA LÍMITE</div><div style={{ fontSize:13, color:GOLD, fontWeight:"bold" }}>{formatFechaCorta(lim)}</div></div></div></>}
            {p.nota && <><div style={{ height:1, background:BORDER, margin:"12px 0" }} /><div style={{ fontSize:12, color:"#888", fontFamily:"sans-serif" }}>📍 {p.nota}</div></>}
          </div>
          <div style={{ background:`${GOLD}11`, border:`1px solid ${GOLD}22`, borderRadius:12, padding:"16px", marginBottom:20 }}>
            <div style={{ display:"flex", justifyContent:"space-between", marginBottom:10 }}>
              <div style={{ fontSize:11, color:GOLD, fontFamily:"sans-serif", letterSpacing:"2px" }}>PROGRESO</div>
              <div style={{ fontSize:13, color:GOLD, fontWeight:"bold" }}>{pct}%</div>
            </div>
            <div style={{ background:"#1A1A1A", borderRadius:6, height:8, overflow:"hidden" }}>
              <div style={{ background:`linear-gradient(90deg,${GOLD},${GOLD_LIGHT})`, width:`${pct}%`, height:"100%", borderRadius:6, boxShadow:`0 0 8px ${GOLD}66` }} />
            </div>
            <div style={{ fontSize:12, color:"#AAA", fontFamily:"sans-serif", marginTop:8 }}>Estado: <span style={{ color:GOLD, fontWeight:"bold" }}>{ESTADO_LABELS[p.estado]}</span></div>
          </div>
          <div style={{ background:"linear-gradient(135deg,#1A0800,#0A0A0A)", border:`1px solid ${GOLD}33`, borderRadius:12, padding:"14px 16px", marginBottom:16, display:"flex", alignItems:"flex-start", gap:10 }}>
            <span style={{ fontSize:20, flexShrink:0 }}>🔥</span>
            <div style={{ fontSize:13, color:"#CCC", fontFamily:"sans-serif", lineHeight:1.6, fontStyle:"italic" }}>{ESTADO_NEURO[p.estado]}</div>
          </div>
          {/* Tips while in production */}
          {(p.estado === 1 || p.estado === 2) && <TipsSection />}
          <div style={{ fontSize:11, color:GOLD, fontFamily:"sans-serif", letterSpacing:"2px", marginBottom:14 }}>LÍNEA DE TIEMPO</div>
          {ESTADO_LABELS.map((est,i) => {
            const done=i<=p.estado; const act=i===p.estado;
            return (
              <div key={i} style={{ display:"flex", gap:16 }}>
                <div style={{ display:"flex", flexDirection:"column", alignItems:"center", width:40, flexShrink:0 }}>
                  <div style={{ width:36,height:36,borderRadius:"50%",background:act?`linear-gradient(135deg,${GOLD},${GOLD_LIGHT})`:done?GOLD+"33":DARK3,border:`2px solid ${done?GOLD:BORDER}`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:16,boxShadow:act?`0 0 16px ${GOLD}66`:"none" }}>{ESTADO_ICONS[i]}</div>
                  {i<ESTADO_LABELS.length-1 && <div style={{ width:2,height:36,background:i<p.estado?`linear-gradient(${GOLD},${GOLD}44)`:BORDER,margin:"2px 0" }} />}
                </div>
                <div style={{ paddingTop:8, paddingBottom:i<ESTADO_LABELS.length-1?24:16 }}>
                  <div style={{ fontSize:14,fontWeight:act?"bold":"normal",color:act?GOLD:done?"#CCC":"#444",fontFamily:"sans-serif" }}>{est}</div>
                  {act && <div style={{ display:"flex",alignItems:"center",gap:6,marginTop:4 }}><div style={{ width:6,height:6,borderRadius:"50%",background:GOLD }} /><span style={{ fontSize:11,color:GOLD,fontFamily:"sans-serif" }}>En curso ahora</span></div>}
                  {done && !act && <div style={{ fontSize:11,color:"#555",fontFamily:"sans-serif",marginTop:2 }}>✓ Completado</div>}
                </div>
              </div>
            );
          })}
          {p.fotos && p.fotos.length > 0 && (
            <div style={{ marginTop:12 }}>
              <div style={{ fontSize:11, color:GOLD, fontFamily:"sans-serif", letterSpacing:"2px", marginBottom:14 }}>📸 FOTOS DE PRODUCCIÓN</div>
              {p.fotos.map((f,i) => (
                <div key={i} style={{ background:CARD, border:`1px solid ${BORDER}`, borderRadius:12, overflow:"hidden", marginBottom:12 }}>
                  <img src={f.src} alt="Progreso" style={{ width:"100%", maxHeight:200, objectFit:"cover", display:"block" }} />
                  <div style={{ padding:"10px 14px" }}>
                    {f.nota && <div style={{ fontSize:13, color:"#CCC", fontFamily:"sans-serif", marginBottom:4 }}>{f.nota}</div>}
                    <div style={{ fontSize:11, color:"#555", fontFamily:"sans-serif" }}>{ESTADO_LABELS[f.etapa]} · {f.fecha} · {f.autor}</div>
                  </div>
                </div>
              ))}
            </div>
          )}
          {/* Review when delivered */}
          {p.estado === 4 && (
            <div style={{ marginTop:16 }}>
              {p.resena ? (
                <div style={{ background:`${GOLD}11`, border:`1px solid ${GOLD}33`, borderRadius:12, padding:"16px", marginBottom:12 }}>
                  <div style={{ fontSize:11, color:GOLD, fontFamily:"sans-serif", letterSpacing:"2px", marginBottom:8 }}>TU RESENA</div>
                  <div style={{ display:"flex", gap:2, marginBottom:6 }}>
                    {[1,2,3,4,5].map(s => <span key={s} style={{ fontSize:20 }}>{s<=p.resena.stars?"*":"-"}</span>)}
                  </div>
                  {p.resena.comment && <div style={{ fontSize:13, color:"#CCC", fontFamily:"sans-serif", fontStyle:"italic" }}>"{p.resena.comment}"</div>}
                  <a href={GOOGLE_REVIEW_URL} target="_blank" rel="noreferrer"
                    style={{ display:"block", marginTop:10, fontSize:12, color:"#4285F4", fontFamily:"sans-serif" }}>
                    Tambien dejar resena en Google →
                  </a>
                </div>
              ) : (
                <ReviewFlow
                  pedido={p}
                  onSave={(resena) => setReviewData({pedidoId: p.id, resena})}
                  onClose={() => setSelected(null)}
                />
              )}
            </div>
          )}
          <div style={{ marginTop:16 }}>
            <a href={`https://wa.me/${WA_NUMBER}?text=Hola! Consulta sobre mi pedido ${p.id}`} target="_blank" rel="noreferrer"
              style={{ display:"flex",alignItems:"center",gap:12,background:"#0A1F0A",border:"1px solid #1A3A1A",borderRadius:12,padding:"16px 20px",textDecoration:"none" }}>
              <span style={{ fontSize:22 }}>💬</span>
              <div><div style={{ fontSize:14,fontWeight:"bold",color:"#4CAF50" }}>Consultar por WhatsApp</div><div style={{ fontSize:12,color:"#666",fontFamily:"sans-serif" }}>+595 994 389 932</div></div>
              <span style={{ marginLeft:"auto",color:"#4CAF50",fontSize:18 }}>›</span>
            </a>
          </div>
        </div>
      </div>
    );
  }
  return (
    <div style={{ paddingBottom:80 }}>
      <Header title="Mis Pedidos" subtitle="SEGUIMIENTO" />
      <div style={{ padding:"16px", display:"flex", flexDirection:"column", gap:12 }}>
        {misPedidos.length===0 && (
          <div style={{ textAlign:"center", padding:"40px 20px" }}>
            <div style={{ fontSize:48, marginBottom:16 }}>🔥</div>
            <div style={{ fontSize:18, fontWeight:"bold", marginBottom:8 }}>Todavía no tenés pedidos</div>
            <div style={{ fontSize:13, color:"#666", fontFamily:"sans-serif", marginBottom:24, lineHeight:1.6 }}>
              ¿Ya elegiste tu parrilla? Explorá el catálogo y contactanos para empezar.
            </div>
            <a href={`https://wa.me/${WA_NUMBER}?text=Hola! Me gustaria consultar sobre una parrilla`} target="_blank" rel="noreferrer"
              style={{ display:"inline-flex", alignItems:"center", gap:8, background:"#0A1F0A", border:"1px solid #1A3A1A", borderRadius:12, padding:"12px 20px", textDecoration:"none", color:"#4CAF50", fontFamily:"sans-serif", fontSize:14, fontWeight:"bold" }}>
              💬 Consultar por WhatsApp
            </a>
          </div>
        )}
        {misPedidos.map((p,i) => {
          const pct=Math.round((p.estado/(ESTADO_LABELS.length-1))*100);
          const base = parseFecha(p.fecha);
          const lim = base && p.diasHabiles ? addDiasHabiles(base, p.diasHabiles) : null;
          const dias = lim ? diasHabilesRestantes(lim) : null;
          return (
            <button key={p.id} onClick={() => setSelected(i)} style={{ background:CARD,border:`1px solid ${BORDER}`,borderRadius:12,padding:"18px",cursor:"pointer",textAlign:"left" }}>
              <div style={{ display:"flex",justifyContent:"space-between",marginBottom:4 }}>
                <div style={{ display:"flex", alignItems:"center", gap:8 }}>
                <div style={{ fontSize:13, color:GOLD, fontFamily:"sans-serif", fontWeight:"bold" }}>{p.id}</div>
                {p.serie && <span style={{ background:GOLD+"22", border:`1px solid ${GOLD}44`, color:GOLD, fontSize:9, padding:"2px 7px", borderRadius:20, fontFamily:"sans-serif", fontWeight:"bold", letterSpacing:"1px" }}>{p.serie}</span>}
              </div>
                <div style={{ fontSize:12,color:"#555",fontFamily:"sans-serif" }}>{p.fecha}</div>
              </div>
              <div style={{ fontSize:16,fontWeight:"bold",marginBottom:6 }}>{p.modelo}</div>
              <div style={{ display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:10 }}>
                <div style={{ display:"flex",alignItems:"center",gap:8 }}>
                  <span>{ESTADO_ICONS[p.estado]}</span>
                  <span style={{ fontSize:13,color:ESTADO_COLORS[p.estado],fontFamily:"sans-serif" }}>{ESTADO_LABELS[p.estado]}</span>
                </div>
                {dias !== null && p.estado < 4 && <CountdownBadge fecha={p.fecha} diasHabiles={p.diasHabiles} size="small" />}
              </div>
              <div style={{ background:BORDER,borderRadius:4,height:4,marginBottom:8,overflow:"hidden" }}>
                <div style={{ background:`linear-gradient(90deg,${GOLD},${GOLD_LIGHT})`,width:`${pct}%`,height:"100%",borderRadius:4 }} />
              </div>
              <div style={{ display:"flex",justifyContent:"space-between" }}>
                <div style={{ fontSize:11,color:"#555",fontFamily:"sans-serif" }}>{pct}% completado</div>
                <div style={{ fontSize:14,color:GOLD,fontWeight:"bold" }}>{p.monto}</div>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}

// ── CLIENT: SOPORTE ───────────────────────────────────────────────────────────
function SoporteScreen({ tickets, setTickets, clienteUser }) {
  const [form, setForm] = useState(false);
  const [tipo, setTipo] = useState("Reclamo");
  const [desc, setDesc] = useState("");
  const [ok, setOk] = useState(false);
  const misTickets = clienteUser ? tickets.filter(t => normalizePhone(t.tel)===normalizePhone(clienteUser.tel)) : [];
  const submit = () => {
    if (desc.length<10||!clienteUser) return;
    setTickets([{ id:`T-0${50+tickets.length}`, tel:clienteUser.tel, tipo, desc, fecha:new Date().toLocaleDateString("es-PY",{day:"2-digit",month:"short",year:"numeric"}), estado:"Abierto" }, ...tickets]);
    setOk(true);
  };
  if (ok) return (
    <div style={{ display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",minHeight:"60vh",padding:32,textAlign:"center" }}>
      <div style={{ fontSize:60,marginBottom:16 }}>✅</div>
      <div style={{ fontSize:22,fontWeight:"bold",marginBottom:8 }}>¡Ticket creado!</div>
      <div style={{ fontSize:14,color:"#888",fontFamily:"sans-serif",marginBottom:28 }}>Te respondemos en menos de 48hs.</div>
      <button onClick={() => { setForm(false);setOk(false);setDesc(""); }} style={{ background:`linear-gradient(135deg,${GOLD},${GOLD_LIGHT})`,border:"none",color:DARK,padding:"14px 32px",borderRadius:8,fontFamily:"sans-serif",fontWeight:"bold",fontSize:14,cursor:"pointer" }}>VER MIS TICKETS</button>
    </div>
  );
  if (form) return (
    <div style={{ paddingBottom:80 }}>
      <Header title="Nueva Solicitud" back onBack={() => setForm(false)} />
      <div style={{ padding:"20px" }}>
        <div style={{ fontSize:11,color:"#888",fontFamily:"sans-serif",letterSpacing:"1px",marginBottom:10 }}>TIPO</div>
        <div style={{ display:"flex",gap:8,marginBottom:20 }}>
          {["Reclamo","Mantenimiento","Consulta"].map(t => (
            <button key={t} onClick={() => setTipo(t)} style={{ flex:1,padding:"10px 4px",borderRadius:8,border:`1px solid ${tipo===t?GOLD:BORDER}`,background:tipo===t?GOLD+"18":CARD,color:tipo===t?GOLD:"#888",fontFamily:"sans-serif",fontSize:12,cursor:"pointer",fontWeight:tipo===t?"bold":"normal" }}>{t}</button>
          ))}
        </div>
        <div style={{ fontSize:11,color:"#888",fontFamily:"sans-serif",letterSpacing:"1px",marginBottom:10 }}>DESCRIPCIÓN</div>
        <textarea value={desc} onChange={e => setDesc(e.target.value)} placeholder="Describí el problema o consulta…"
          style={{ width:"100%",height:140,background:CARD,border:`1px solid ${BORDER}`,color:"#F0F0F0",padding:"14px",borderRadius:10,fontSize:14,fontFamily:"sans-serif",outline:"none",resize:"none",boxSizing:"border-box",marginBottom:16 }} />
        <button onClick={submit} style={{ width:"100%",background:desc.length>10?`linear-gradient(135deg,${GOLD},${GOLD_LIGHT})`:BORDER,border:"none",color:desc.length>10?DARK:"#555",padding:"16px",borderRadius:10,fontSize:15,fontFamily:"sans-serif",fontWeight:"bold",letterSpacing:"2px",cursor:desc.length>10?"pointer":"default" }}>ENVIAR SOLICITUD</button>
      </div>
    </div>
  );
  const tc = { "Abierto":"#E57373","En proceso":GOLD,"Resuelto":"#4CAF50" };
  return (
    <div style={{ paddingBottom:80 }}>
      <Header title="Soporte" subtitle="RECLAMOS Y MANTENIMIENTO" />
      <div style={{ padding:"16px" }}>
        <button onClick={() => setForm(true)} style={{ width:"100%",background:`${GOLD}11`,border:`1px solid ${GOLD}55`,borderRadius:12,padding:"18px 20px",display:"flex",alignItems:"center",gap:14,cursor:"pointer",marginBottom:20 }}>
          <div style={{ width:44,height:44,background:GOLD+"22",borderRadius:10,display:"flex",alignItems:"center",justifyContent:"center",fontSize:22 }}>➕</div>
          <div style={{ textAlign:"left" }}><div style={{ fontSize:16,fontWeight:"bold",color:GOLD }}>Nueva solicitud</div><div style={{ fontSize:12,color:"#888",fontFamily:"sans-serif" }}>Reclamo, mantenimiento o consulta</div></div>
        </button>
        {misTickets.length===0 && <div style={{ textAlign:"center",padding:"30px 20px",color:"#555",fontFamily:"sans-serif" }}><div style={{ fontSize:36,marginBottom:10 }}>🔧</div><div>No tenés solicitudes activas.</div></div>}
        {misTickets.map(t => (
          <div key={t.id} style={{ background:CARD,border:`1px solid ${BORDER}`,borderRadius:12,padding:"16px",marginBottom:10 }}>
            <div style={{ display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:8 }}>
              <div style={{ display:"flex",gap:8,alignItems:"center" }}><span style={{ fontSize:12,color:"#666",fontFamily:"sans-serif" }}>{t.id}</span><Tag label={t.tipo} color={tc[t.estado]||GOLD} /></div>
              <div style={{ background:tc[t.estado]+"22",border:`1px solid ${tc[t.estado]}44`,color:tc[t.estado],fontSize:11,padding:"3px 10px",borderRadius:20,fontFamily:"sans-serif" }}>{t.estado}</div>
            </div>
            <div style={{ fontSize:14,color:"#CCC",fontFamily:"sans-serif",marginBottom:6 }}>{t.desc}</div>
            <div style={{ fontSize:11,color:"#555",fontFamily:"sans-serif" }}>{t.fecha}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ── ADMIN: CLIENTES ───────────────────────────────────────────────────────────
function AdminClientes({ clientes, setClientes }) {
  const [view, setView] = useState("list");
  const [idx, setIdx] = useState(null);
  const emptyForm = { nombre:"", tel:"", dir:"", historial:"" };
  const [form, setForm] = useState(emptyForm);
  const [error, setError] = useState("");
  const openAdd  = () => { setForm(emptyForm); setIdx(null); setError(""); setView("form"); };
  const openEdit = (i) => { setForm({ ...clientes[i] }); setIdx(i); setError(""); setView("form"); };
  const guardar = () => {
    if (!form.nombre.trim()) { setError("El nombre es obligatorio."); return; }
    if (normalizePhone(form.tel).length < 7) { setError("Ingresá un número válido."); return; }
    if (idx === null) setClientes([...clientes, { ...form, id:`C-${String(clientes.length+1).padStart(3,"0")}`, tel:normalizePhone(form.tel) }]);
    else setClientes(clientes.map((c,i) => i===idx ? { ...form, tel:normalizePhone(form.tel) } : c));
    setView("list"); setError("");
  };
  const eliminar = (i) => { setClientes(clientes.filter((_,j)=>j!==i)); setView("list"); };
  if (view==="form") return (
    <div style={{ paddingBottom:80 }}>
      <Header title={idx===null?"Nuevo Cliente":"Editar Cliente"} subtitle="GESTIÓN DE CLIENTES" back onBack={() => { setView(idx===null?"list":"detail"); setError(""); }} />
      <div style={{ padding:"20px", display:"flex", flexDirection:"column", gap:16 }}>
        <div>
          <div style={{ fontSize:11, color:GOLD, fontFamily:"sans-serif", letterSpacing:"1px", marginBottom:8 }}>CÓDIGO DE CLIENTE</div>
          <input
            placeholder="Ej: CLI-001, VIP-GARCIA..."
            value={form.codigo || ""}
            onChange={e => setForm({...form, codigo: e.target.value.toUpperCase()})}
            style={{ width:"100%", background:CARD, border:`1px solid ${GOLD}55`, color:GOLD, padding:"14px 16px", borderRadius:8, fontSize:15, fontFamily:"sans-serif", outline:"none", boxSizing:"border-box", fontWeight:"bold", letterSpacing:"2px" }}
          />
          <div style={{ fontSize:10, color:"#555", fontFamily:"sans-serif", marginTop:4 }}>Este código identifica al cliente en el sistema</div>
        </div>
        {[{label:"NOMBRE COMPLETO",key:"nombre",ph:"Ej: Juan Pérez",type:"text"},{label:"TELÉFONO",key:"tel",ph:"09XX XXX XXX",type:"tel"},{label:"DIRECCIÓN",key:"dir",ph:"Calle, ciudad...",type:"text"}].map(f => (
          <div key={f.key}>
            <div style={{ fontSize:11,color:"#888",fontFamily:"sans-serif",letterSpacing:"1px",marginBottom:8 }}>{f.label}</div>
            <input type={f.type} placeholder={f.ph} value={form[f.key]} onChange={e => setForm({...form,[f.key]:e.target.value})}
              style={{ width:"100%",background:CARD,border:`1px solid ${BORDER}`,color:"#F0F0F0",padding:"14px 16px",borderRadius:8,fontSize:15,fontFamily:"sans-serif",outline:"none",boxSizing:"border-box" }} />
          </div>
        ))}
        <div>
          <div style={{ fontSize:11,color:"#888",fontFamily:"sans-serif",letterSpacing:"1px",marginBottom:8 }}>HISTORIAL / REFERENCIA</div>
          <textarea value={form.historial} onChange={e => setForm({...form,historial:e.target.value})} placeholder="Observaciones, preferencias, historial de compras…"
            style={{ width:"100%",height:100,background:CARD,border:`1px solid ${BORDER}`,color:"#F0F0F0",padding:"14px",borderRadius:8,fontSize:14,fontFamily:"sans-serif",outline:"none",resize:"none",boxSizing:"border-box" }} />
        </div>
        {error && <div style={{ fontSize:12,color:"#E57373",fontFamily:"sans-serif" }}>{error}</div>}
        <button onClick={guardar} style={{ width:"100%",background:`linear-gradient(135deg,${GOLD},${GOLD_LIGHT})`,border:"none",color:DARK,padding:"16px",borderRadius:10,fontSize:15,fontFamily:"sans-serif",fontWeight:"bold",letterSpacing:"2px",cursor:"pointer" }}>{idx===null?"GUARDAR CLIENTE":"GUARDAR CAMBIOS"}</button>
        {idx !== null && <button onClick={() => eliminar(idx)} style={{ width:"100%",background:"none",border:"1px solid #E57373",color:"#E57373",padding:"14px",borderRadius:10,fontSize:14,fontFamily:"sans-serif",cursor:"pointer" }}>🗑 Eliminar cliente</button>}
      </div>
    </div>
  );
  if (view==="detail" && idx!==null) {
    const c = clientes[idx];
    return (
      <div style={{ paddingBottom:80 }}>
        <Header title={c.nombre} subtitle="DETALLE DE CLIENTE" back onBack={() => setView("list")} />
        <div style={{ padding:"20px" }}>
          <div style={{ background:CARD,border:`1px solid ${BORDER}`,borderRadius:12,padding:"20px",marginBottom:16 }}>
            <div style={{ display:"flex",alignItems:"center",gap:16,marginBottom:20 }}>
              <div style={{ width:56,height:56,borderRadius:"50%",background:`${GOLD}22`,border:`2px solid ${GOLD}44`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:26 }}>👤</div>
              <div><div style={{ fontSize:20,fontWeight:"bold" }}>{c.nombre}</div><div style={{ fontSize:12,color:"#666",fontFamily:"sans-serif",marginTop:2 }}>{c.id}</div></div>
            </div>
            <div style={{ height:1,background:BORDER,marginBottom:16 }} />
            {[{icon:"📞",label:"Teléfono",val:c.tel},{icon:"📍",label:"Dirección",val:c.dir||"—"}].map(r => (
              <div key={r.label} style={{ display:"flex",gap:12,alignItems:"flex-start",marginBottom:14 }}>
                <span style={{ fontSize:18,marginTop:2 }}>{r.icon}</span>
                <div><div style={{ fontSize:10,color:"#555",fontFamily:"sans-serif",marginBottom:2 }}>{r.label.toUpperCase()}</div><div style={{ fontSize:14,color:"#CCC",fontFamily:"sans-serif" }}>{r.val}</div></div>
              </div>
            ))}
            {c.historial && <><div style={{ height:1,background:BORDER,marginBottom:14 }} /><div style={{ fontSize:10,color:"#555",fontFamily:"sans-serif",marginBottom:6 }}>HISTORIAL</div><div style={{ fontSize:13,color:"#AAA",fontFamily:"sans-serif",lineHeight:1.6 }}>{c.historial}</div></>}
          </div>
          <button onClick={() => openEdit(idx)} style={{ width:"100%",background:`linear-gradient(135deg,${GOLD},${GOLD_LIGHT})`,border:"none",color:DARK,padding:"14px",borderRadius:10,fontSize:14,fontFamily:"sans-serif",fontWeight:"bold",cursor:"pointer",marginBottom:10 }}>✏️ Editar cliente</button>
          <a href={`https://wa.me/595${c.tel.replace(/^0/,"")}`} target="_blank" rel="noreferrer"
            style={{ display:"flex",alignItems:"center",justifyContent:"center",gap:8,background:"#0A1F0A",border:"1px solid #1A3A1A",borderRadius:10,padding:"14px",textDecoration:"none",color:"#4CAF50",fontFamily:"sans-serif",fontSize:14 }}>
            💬 Contactar por WhatsApp
          </a>
        </div>
      </div>
    );
  }
  return (
    <div style={{ paddingBottom:80 }}>
      <div style={{ padding:"20px 20px 16px",borderBottom:`1px solid ${BORDER}` }}>
        <div style={{ fontSize:10,color:GOLD,fontFamily:"sans-serif",letterSpacing:"3px",marginBottom:4 }}>PANEL DE GESTIÓN</div>
        <div style={{ fontSize:22,fontWeight:"bold" }}>Clientes</div>
      </div>
      <div style={{ padding:"16px 16px 0",display:"grid",gridTemplateColumns:"1fr 1fr",gap:10,marginBottom:4 }}>
        <div style={{ background:CARD,border:`1px solid ${BORDER}`,borderRadius:10,padding:"14px",textAlign:"center" }}><div style={{ fontSize:28,fontWeight:"bold",color:GOLD }}>{clientes.length}</div><div style={{ fontSize:11,color:"#666",fontFamily:"sans-serif",marginTop:2 }}>Total</div></div>
        <div style={{ background:CARD,border:`1px solid ${BORDER}`,borderRadius:10,padding:"14px",textAlign:"center" }}><div style={{ fontSize:28,fontWeight:"bold",color:"#4CAF50" }}>{clientes.filter(c=>c.historial).length}</div><div style={{ fontSize:11,color:"#666",fontFamily:"sans-serif",marginTop:2 }}>Con historial</div></div>
      </div>
      <div style={{ padding:"16px",display:"flex",flexDirection:"column",gap:10 }}>
        <button onClick={openAdd} style={{ background:`${GOLD}11`,border:`1px solid ${GOLD}55`,borderRadius:12,padding:"16px 20px",display:"flex",alignItems:"center",gap:14,cursor:"pointer" }}>
          <div style={{ width:44,height:44,background:GOLD+"22",borderRadius:10,display:"flex",alignItems:"center",justifyContent:"center",fontSize:22 }}>➕</div>
          <div style={{ textAlign:"left" }}><div style={{ fontSize:16,fontWeight:"bold",color:GOLD }}>Agregar cliente</div><div style={{ fontSize:12,color:"#888",fontFamily:"sans-serif" }}>Nombre, teléfono, dirección e historial</div></div>
        </button>
        <div style={{ fontSize:11,color:GOLD,fontFamily:"sans-serif",letterSpacing:"2px",marginTop:4,marginBottom:2 }}>LISTA DE CLIENTES</div>
        {clientes.map((c,i) => (
          <button key={c.id} onClick={() => { setIdx(i); setView("detail"); }} style={{ background:CARD,border:`1px solid ${BORDER}`,borderRadius:12,padding:"16px",cursor:"pointer",textAlign:"left",display:"flex",alignItems:"center",gap:14 }}>
            <div style={{ width:44,height:44,borderRadius:"50%",background:`${GOLD}18`,border:`1px solid ${GOLD}33`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:20,flexShrink:0 }}>👤</div>
            <div style={{ flex:1 }}>
              <div style={{ display:"flex", alignItems:"center", gap:8, marginBottom:3 }}>
                <div style={{ fontSize:15, fontWeight:"bold" }}>{c.nombre}</div>
                {c.codigo && <span style={{ background:GOLD+"22", border:`1px solid ${GOLD}55`, color:GOLD, fontSize:9, padding:"2px 7px", borderRadius:20, fontFamily:"sans-serif", fontWeight:"bold", letterSpacing:"1px" }}>{c.codigo}</span>}
              </div>
              <div style={{ fontSize:12,color:GOLD,fontFamily:"sans-serif",marginBottom:2 }}>📞 {c.tel}</div>
              {c.dir && <div style={{ fontSize:12,color:"#666",fontFamily:"sans-serif" }}>📍 {c.dir}</div>}
            </div>
            {c.historial && <span style={{ fontSize:16 }}>📋</span>}
            <span style={{ color:GOLD,fontSize:18 }}>›</span>
          </button>
        ))}
      </div>
    </div>
  );
}

// ── ADMIN: CATÁLOGO ───────────────────────────────────────────────────────────
function AdminCatalog({ productos, setProductos }) {
  const [view, setView] = useState("list");
  const [idx, setIdx] = useState(null);
  const emptyForm = { nombre:"", precio:"", desc:"", specs:[], colores:[], foto:null, tag:"", emoji:"🔥" };
  const [form, setForm] = useState(emptyForm);
  const [newSpec, setNewSpec] = useState("");
  const COLORES_OPT = ["Grill","Negro"];
  const openEdit = (i) => { setForm({ ...productos[i], specs:[...productos[i].specs], colores:[...productos[i].colores] }); setIdx(i); setView("form"); };
  const openAdd  = () => { setForm(emptyForm); setIdx(null); setView("form"); };
  const toggleColor = (c) => setForm(f => ({ ...f, colores: f.colores.includes(c)?f.colores.filter(x=>x!==c):[...f.colores,c] }));
  const addSpec = () => { if (newSpec.trim()) { setForm(f=>({...f,specs:[...f.specs,newSpec.trim()]})); setNewSpec(""); } };
  const removeSpec = (i) => setForm(f=>({...f,specs:f.specs.filter((_,j)=>j!==i)}));
  const guardar = () => {
    if (!form.nombre.trim()) return;
    if (idx===null) setProductos([...productos,{...form,id:Date.now()}]);
    else setProductos(productos.map((p,i)=>i===idx?{...p,...form}:p));
    setView("list");
  };
  if (view==="form") return (
    <div style={{ paddingBottom:80 }}>
      <Header title={idx===null?"Nuevo Producto":"Editar Producto"} subtitle="CATÁLOGO" back onBack={() => setView("list")} />
      <div style={{ padding:"20px", display:"flex", flexDirection:"column", gap:18 }}>
        <div>
          <div style={{ fontSize:11,color:"#888",fontFamily:"sans-serif",letterSpacing:"1px",marginBottom:10 }}>FOTO DEL PRODUCTO</div>
          {form.foto
            ? <div style={{ position:"relative",borderRadius:12,overflow:"hidden",marginBottom:10 }}><img src={form.foto} alt="producto" style={{ width:"100%",height:180,objectFit:"cover",display:"block" }} /><button onClick={() => setForm(f=>({...f,foto:null}))} style={{ position:"absolute",top:8,right:8,background:"#000000AA",border:"none",color:"#FFF",borderRadius:"50%",width:32,height:32,cursor:"pointer",fontSize:16 }}>✕</button></div>
            : <div style={{ height:120,background:DARK3,border:`1px dashed ${BORDER}`,borderRadius:12,display:"flex",alignItems:"center",justifyContent:"center",marginBottom:10,fontSize:40 }}>{form.emoji}</div>
          }
          <PhotoUploadButton onPhoto={(src) => setForm(f=>({...f,foto:src}))} label="📷 Subir foto del producto" style={{ width:"100%",justifyContent:"center",boxSizing:"border-box" }} />
        </div>
        {[{label:"NOMBRE",key:"nombre",ph:"Ej: El Patrón 900"},{label:"PRECIO",key:"precio",ph:"Ej: Gs. 4.200.000"},{label:"ETIQUETA",key:"tag",ph:"Ej: MÁS VENDIDO"}].map(f => (
          <div key={f.key}>
            <div style={{ fontSize:11,color:"#888",fontFamily:"sans-serif",letterSpacing:"1px",marginBottom:8 }}>{f.label}</div>
            <input placeholder={f.ph} value={form[f.key]} onChange={e=>setForm(fm=>({...fm,[f.key]:e.target.value}))}
              style={{ width:"100%",background:CARD,border:`1px solid ${BORDER}`,color:"#F0F0F0",padding:"14px 16px",borderRadius:8,fontSize:15,fontFamily:"sans-serif",outline:"none",boxSizing:"border-box" }} />
          </div>
        ))}
        <div>
          <div style={{ fontSize:11,color:"#888",fontFamily:"sans-serif",letterSpacing:"1px",marginBottom:8 }}>DESCRIPCIÓN</div>
          <textarea value={form.desc} onChange={e=>setForm(f=>({...f,desc:e.target.value}))} placeholder="Descripción del producto…"
            style={{ width:"100%",height:90,background:CARD,border:`1px solid ${BORDER}`,color:"#F0F0F0",padding:"14px",borderRadius:8,fontSize:14,fontFamily:"sans-serif",outline:"none",resize:"none",boxSizing:"border-box" }} />
        </div>
        <div>
          <div style={{ fontSize:11,color:"#888",fontFamily:"sans-serif",letterSpacing:"1px",marginBottom:10 }}>COLORES DISPONIBLES</div>
          <div style={{ display:"flex",gap:10 }}>
            {COLORES_OPT.map(c => (
              <button key={c} onClick={() => toggleColor(c)} style={{ flex:1,padding:"14px",borderRadius:10,border:`2px solid ${form.colores.includes(c)?GOLD:BORDER}`,background:form.colores.includes(c)?GOLD+"18":CARD,cursor:"pointer",display:"flex",flexDirection:"column",alignItems:"center",gap:8 }}>
                <div style={{ width:32,height:32,borderRadius:"50%",background:c==="Negro"?"#1a1a1a":"#C0C0C0",border:`2px solid ${c==="Negro"?"#444":"#888"}` }} />
                <span style={{ fontSize:13,color:form.colores.includes(c)?GOLD:"#888",fontFamily:"sans-serif",fontWeight:form.colores.includes(c)?"bold":"normal" }}>{c}</span>
              </button>
            ))}
          </div>
        </div>
        <div>
          <div style={{ fontSize:11,color:"#888",fontFamily:"sans-serif",letterSpacing:"1px",marginBottom:10 }}>ESPECIFICACIONES</div>
          <div style={{ display:"flex",gap:8,marginBottom:10 }}>
            <input placeholder="Agregar especificación…" value={newSpec} onChange={e=>setNewSpec(e.target.value)} onKeyDown={e=>e.key==="Enter"&&addSpec()}
              style={{ flex:1,background:CARD,border:`1px solid ${BORDER}`,color:"#F0F0F0",padding:"12px 14px",borderRadius:8,fontSize:14,fontFamily:"sans-serif",outline:"none" }} />
            <button onClick={addSpec} style={{ background:GOLD,border:"none",color:DARK,padding:"12px 16px",borderRadius:8,fontFamily:"sans-serif",fontWeight:"bold",cursor:"pointer",fontSize:16 }}>+</button>
          </div>
          <div style={{ display:"flex",flexWrap:"wrap",gap:8 }}>
            {form.specs.map((s,i) => (
              <div key={i} style={{ background:DARK3,border:`1px solid ${BORDER}`,borderRadius:20,padding:"6px 12px",display:"flex",alignItems:"center",gap:8 }}>
                <span style={{ fontSize:13,color:"#CCC",fontFamily:"sans-serif" }}>✓ {s}</span>
                <button onClick={() => removeSpec(i)} style={{ background:"none",border:"none",color:"#E57373",cursor:"pointer",fontSize:14 }}>✕</button>
              </div>
            ))}
          </div>
        </div>
        <button onClick={guardar} style={{ width:"100%",background:`linear-gradient(135deg,${GOLD},${GOLD_LIGHT})`,border:"none",color:DARK,padding:"16px",borderRadius:10,fontSize:15,fontFamily:"sans-serif",fontWeight:"bold",letterSpacing:"2px",cursor:"pointer" }}>
          {idx===null?"AGREGAR PRODUCTO":"GUARDAR CAMBIOS"}
        </button>
      </div>
    </div>
  );
  return (
    <div style={{ paddingBottom:80 }}>
      <div style={{ padding:"20px 20px 16px",borderBottom:`1px solid ${BORDER}` }}>
        <div style={{ fontSize:10,color:GOLD,fontFamily:"sans-serif",letterSpacing:"3px",marginBottom:4 }}>PANEL DE GESTIÓN</div>
        <div style={{ fontSize:22,fontWeight:"bold" }}>Catálogo</div>
      </div>
      <div style={{ padding:"16px",display:"flex",flexDirection:"column",gap:10 }}>
        <button onClick={openAdd} style={{ background:`${GOLD}11`,border:`1px solid ${GOLD}55`,borderRadius:12,padding:"16px 20px",display:"flex",alignItems:"center",gap:14,cursor:"pointer" }}>
          <div style={{ width:44,height:44,background:GOLD+"22",borderRadius:10,display:"flex",alignItems:"center",justifyContent:"center",fontSize:22 }}>➕</div>
          <div style={{ textAlign:"left" }}><div style={{ fontSize:16,fontWeight:"bold",color:GOLD }}>Agregar producto</div><div style={{ fontSize:12,color:"#888",fontFamily:"sans-serif" }}>Con foto, color y especificaciones</div></div>
        </button>
        {productos.map((p,i) => (
          <div key={p.id} style={{ background:CARD,border:`1px solid ${BORDER}`,borderRadius:12,overflow:"hidden" }}>
            {p.foto && <img src={p.foto} alt={p.nombre} style={{ width:"100%",height:110,objectFit:"cover",display:"block",borderBottom:`1px solid ${BORDER}` }} />}
            <div style={{ padding:"14px 16px",display:"flex",alignItems:"center",gap:14 }}>
              {!p.foto && <div style={{ width:48,height:48,background:"#1A1200",borderRadius:10,display:"flex",alignItems:"center",justifyContent:"center",fontSize:26,flexShrink:0 }}>{p.emoji}</div>}
              <div style={{ flex:1 }}>
                <div style={{ display:"flex",justifyContent:"space-between",marginBottom:4 }}><div style={{ fontSize:15,fontWeight:"bold" }}>{p.nombre}</div><Tag label={p.tag} /></div>
                <div style={{ fontSize:14,color:GOLD,fontFamily:"sans-serif",marginBottom:4 }}>{p.precio}</div>
                <div style={{ display:"flex",gap:6 }}>{p.colores.map(c => <span key={c} style={{ fontSize:10,color:"#888",fontFamily:"sans-serif",background:DARK3,border:`1px solid ${BORDER}`,padding:"2px 8px",borderRadius:20 }}>{c}</span>)}</div>
              </div>
              <button onClick={() => openEdit(i)} style={{ background:GOLD+"22",border:`1px solid ${GOLD}44`,color:GOLD,padding:"8px 14px",borderRadius:8,fontFamily:"sans-serif",fontSize:12,cursor:"pointer",flexShrink:0 }}>✏️ Editar</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ── ADMIN: PEDIDOS ────────────────────────────────────────────────────────────
function AdminOrders({ pedidos, setPedidos, clientes, adminUser, productos }) {
  const [selected, setSelected] = useState(null);
  const [nota, setNota] = useState("");
  const [view, setView] = useState("list"); // list | new
  const [filterStatus, setFilterStatus] = useState("all");
  const [newForm, setNewForm] = useState({
    clienteId:"", modelo:"", monto:"", nota:"", serie:"", diasHabiles:10
  });
  const tc = { 0:"#888",1:GOLD,2:GOLD_LIGHT,3:"#4CAF50",4:"#4CAF50" };
  const getNombre = (tel) => { const c=clientes.find(x=>normalizePhone(x.tel)===normalizePhone(tel)); return c?c.nombre:tel; };

  const crearPedido = () => {
    const cliente = clientes.find(c => c.id === newForm.clienteId);
    if (!cliente || !newForm.modelo || !newForm.monto) return;
    const fecha = new Date().toLocaleDateString("es-PY",{day:"2-digit",month:"short",year:"numeric"});
    const num = String(pedidos.length + 1).padStart(3, "0");
    const year = new Date().getFullYear();
    const nuevo = {
      id: `DP-${year}-${num}`,
      serie: newForm.serie.trim().toUpperCase() || `PED-${year}-${num}`,
      tel: cliente.tel,
      modelo: newForm.modelo,
      fecha,
      estado: 0,
      monto: newForm.monto,
      nota: newForm.nota,
      fotos: [],
      diasHabiles: newForm.diasHabiles
    };
    setPedidos([nuevo, ...pedidos]);
    setNewForm({ clienteId:"", modelo:"", monto:"", nota:"", serie:"", diasHabiles:10 });
    setView("list");
  };

  // ── NEW ORDER FORM ──
  if (view === "new") {
    const clienteSeleccionado = clientes.find(c => c.id === newForm.clienteId);
    const formOk = newForm.clienteId && newForm.modelo && newForm.monto;
    return (
      <div style={{ paddingBottom:80 }}>
        <Header title="Nuevo Pedido" subtitle="CREAR PEDIDO" back onBack={() => setView("list")} />
        <div style={{ padding:"20px", display:"flex", flexDirection:"column", gap:16 }}>

          {/* Select client */}
          <div>
            <div style={{ fontSize:11, color:GOLD, fontFamily:"sans-serif", letterSpacing:"1px", marginBottom:10 }}>CLIENTE *</div>
            <div style={{ display:"flex", flexDirection:"column", gap:8, maxHeight:200, overflowY:"auto" }}>
              {clientes.map(c => (
                <button key={c.id} onClick={() => setNewForm({...newForm, clienteId: c.id})}
                  style={{ background: newForm.clienteId===c.id ? GOLD+"22" : CARD, border:`1px solid ${newForm.clienteId===c.id ? GOLD : BORDER}`, borderRadius:10, padding:"12px 16px", cursor:"pointer", textAlign:"left", display:"flex", alignItems:"center", gap:12 }}>
                  <div style={{ width:36, height:36, borderRadius:"50%", background:GOLD+"18", border:`1px solid ${GOLD}33`, display:"flex", alignItems:"center", justifyContent:"center", fontSize:16, flexShrink:0 }}>👤</div>
                  <div>
                    <div style={{ fontSize:14, fontWeight:"bold", color: newForm.clienteId===c.id ? GOLD : "#F0F0F0" }}>{c.nombre}</div>
                    <div style={{ fontSize:11, color:"#888", fontFamily:"sans-serif" }}>{c.tel}{c.codigo ? ` · ${c.codigo}` : ""}</div>
                  </div>
                  {newForm.clienteId===c.id && <span style={{ marginLeft:"auto", color:GOLD, fontSize:18 }}>✓</span>}
                </button>
              ))}
              {clientes.length === 0 && <div style={{ color:"#555", fontFamily:"sans-serif", fontSize:13, padding:"16px", textAlign:"center" }}>No hay clientes registrados aún</div>}
            </div>
          </div>

          {/* Select model */}
          <div>
            <div style={{ fontSize:11, color:GOLD, fontFamily:"sans-serif", letterSpacing:"1px", marginBottom:10 }}>MODELO / PRODUCTO *</div>
            <div style={{ display:"flex", flexDirection:"column", gap:8 }}>
              {productos.map(p => (
                <button key={p.id} onClick={() => setNewForm({...newForm, modelo: p.nombre})}
                  style={{ background: newForm.modelo===p.nombre ? GOLD+"22" : CARD, border:`1px solid ${newForm.modelo===p.nombre ? GOLD : BORDER}`, borderRadius:10, padding:"12px 16px", cursor:"pointer", textAlign:"left", display:"flex", alignItems:"center", gap:12 }}>
                  <span style={{ fontSize:24 }}>{p.emoji}</span>
                  <div style={{ flex:1 }}>
                    <div style={{ fontSize:14, fontWeight:"bold", color: newForm.modelo===p.nombre ? GOLD : "#F0F0F0" }}>{p.nombre}</div>
                    <div style={{ fontSize:12, color:GOLD, fontFamily:"sans-serif" }}>{p.precio}</div>
                  </div>
                  {newForm.modelo===p.nombre && <span style={{ color:GOLD, fontSize:18 }}>✓</span>}
                </button>
              ))}
              {/* Custom model option */}
              <div>
                <input
                  placeholder="O escribí un modelo personalizado..."
                  value={productos.some(p=>p.nombre===newForm.modelo) ? "" : newForm.modelo}
                  onChange={e => setNewForm({...newForm, modelo: e.target.value})}
                  style={{ width:"100%", background:CARD, border:`1px solid ${BORDER}`, color:"#F0F0F0", padding:"12px 14px", borderRadius:10, fontSize:14, fontFamily:"sans-serif", outline:"none", boxSizing:"border-box" }}
                />
              </div>
            </div>
          </div>

          {/* Monto */}
          <div>
            <div style={{ fontSize:11, color:"#888", fontFamily:"sans-serif", letterSpacing:"1px", marginBottom:8 }}>MONTO *</div>
            <input
              placeholder="Ej: Gs. 4.200.000"
              value={newForm.monto}
              onChange={e => setNewForm({...newForm, monto: e.target.value})}
              style={{ width:"100%", background:CARD, border:`1px solid ${BORDER}`, color:"#F0F0F0", padding:"14px 16px", borderRadius:8, fontSize:15, fontFamily:"sans-serif", outline:"none", boxSizing:"border-box" }}
            />
          </div>

          {/* Serie */}
          <div>
            <div style={{ fontSize:11, color:"#888", fontFamily:"sans-serif", letterSpacing:"1px", marginBottom:8 }}>N° DE SERIE (opcional)</div>
            <input
              placeholder="Ej: PED-2026-004 (se genera automático)"
              value={newForm.serie}
              onChange={e => setNewForm({...newForm, serie: e.target.value.toUpperCase()})}
              style={{ width:"100%", background:CARD, border:`1px solid ${GOLD}44`, color:GOLD, padding:"14px 16px", borderRadius:8, fontSize:15, fontFamily:"sans-serif", outline:"none", boxSizing:"border-box", fontWeight:"bold", letterSpacing:"1.5px" }}
            />
          </div>

          {/* Días hábiles */}
          <div>
            <div style={{ fontSize:11, color:"#888", fontFamily:"sans-serif", letterSpacing:"1px", marginBottom:10 }}>DÍAS HÁBILES DE ENTREGA</div>
            <div style={{ display:"flex", gap:8 }}>
              {[5,8,10,15,20].map(n => (
                <button key={n} onClick={() => setNewForm({...newForm, diasHabiles:n})}
                  style={{ flex:1, padding:"10px 4px", borderRadius:8, border:`1px solid ${newForm.diasHabiles===n?GOLD:BORDER}`, background:newForm.diasHabiles===n?GOLD+"18":CARD, color:newForm.diasHabiles===n?GOLD:"#888", fontFamily:"sans-serif", fontSize:13, cursor:"pointer", fontWeight:newForm.diasHabiles===n?"bold":"normal" }}>
                  {n}d
                </button>
              ))}
            </div>
          </div>

          {/* Nota */}
          <div>
            <div style={{ fontSize:11, color:"#888", fontFamily:"sans-serif", letterSpacing:"1px", marginBottom:8 }}>NOTA / OBSERVACIÓN</div>
            <input
              placeholder="Ej: Entrega a domicilio, retira en taller..."
              value={newForm.nota}
              onChange={e => setNewForm({...newForm, nota: e.target.value})}
              style={{ width:"100%", background:CARD, border:`1px solid ${BORDER}`, color:"#F0F0F0", padding:"14px 16px", borderRadius:8, fontSize:14, fontFamily:"sans-serif", outline:"none", boxSizing:"border-box" }}
            />
          </div>

          {!formOk && <div style={{ fontSize:12, color:"#E57373", fontFamily:"sans-serif", textAlign:"center" }}>* Seleccioná cliente, modelo y monto para continuar</div>}

          <button onClick={crearPedido} disabled={!formOk}
            style={{ width:"100%", background:formOk?`linear-gradient(135deg,${GOLD},${GOLD_LIGHT})`:BORDER, border:"none", color:formOk?DARK:"#555", padding:"16px", borderRadius:10, fontSize:15, fontFamily:"sans-serif", fontWeight:"bold", letterSpacing:"2px", cursor:formOk?"pointer":"default" }}>
            ✅ CREAR PEDIDO
          </button>
        </div>
      </div>
    );
  }

  if (selected !== null) {
    const p = pedidos[selected];
    const pct = Math.round((p.estado/(ESTADO_LABELS.length-1))*100);
    const cliente = clientes.find(x=>normalizePhone(x.tel)===normalizePhone(p.tel));
    const addFoto = (src) => {
      const f = { src, nota:nota.trim(), etapa:p.estado, fecha:new Date().toLocaleDateString("es-PY",{day:"2-digit",month:"short",year:"numeric"}), autor:adminUser?.nombre||"Admin" };
      setPedidos(pedidos.map((x,i)=>i===selected?{...x,fotos:[...(x.fotos||[]),f]}:x));
      setNota("");
    };
    const setDiasHabiles = (val) => {
      const num = parseInt(val);
      if (isNaN(num)||num<1) return;
      setPedidos(pedidos.map((x,i)=>i===selected?{...x,diasHabiles:num}:x));
    };
    const base = parseFecha(p.fecha);
    const lim  = base && p.diasHabiles ? addDiasHabiles(base, p.diasHabiles) : null;
    return (
      <div style={{ paddingBottom:80 }}>
        <Header title={p.id} subtitle="GESTIÓN DE PEDIDO" back onBack={() => { setSelected(null); setNota(""); }} />
        <div style={{ padding:"20px" }}>
          {lim && p.estado < 4 && <div style={{ marginBottom:20 }}><CountdownBadge fecha={p.fecha} diasHabiles={p.diasHabiles} /></div>}
          <div style={{ background:CARD,border:`1px solid ${BORDER}`,borderRadius:12,padding:"16px 20px",marginBottom:20 }}>
            {p.serie && (
              <div style={{ background:GOLD+"15", border:`1px solid ${GOLD}44`, borderRadius:8, padding:"8px 14px", marginBottom:14, display:"flex", alignItems:"center", justifyContent:"space-between" }}>
                <div style={{ fontSize:10, color:GOLD, fontFamily:"sans-serif", letterSpacing:"2px" }}>N° DE SERIE</div>
                <div style={{ fontSize:16, color:GOLD, fontWeight:"bold", fontFamily:"sans-serif", letterSpacing:"2px" }}>{p.serie}</div>
              </div>
            )}
            <div style={{ fontSize:11,color:"#555",fontFamily:"sans-serif",marginBottom:6 }}>CLIENTE</div>
            <div style={{ fontSize:18,fontWeight:"bold",marginBottom:4 }}>{cliente?cliente.nombre:p.tel}</div>
            <div style={{ fontSize:13,color:GOLD,fontFamily:"sans-serif",marginBottom:cliente?.dir?4:0 }}>{p.tel}</div>
            {cliente?.dir && <div style={{ fontSize:12,color:"#888",fontFamily:"sans-serif",marginBottom:12 }}>📍 {cliente.dir}</div>}
            <div style={{ height:1,background:BORDER,margin:"12px 0" }} />
            <div style={{ display:"grid",gridTemplateColumns:"1fr 1fr",gap:12 }}>
              <div><div style={{ fontSize:10,color:"#555",fontFamily:"sans-serif",marginBottom:3 }}>MODELO</div><div style={{ fontSize:13,color:"#CCC",fontFamily:"sans-serif" }}>{p.modelo}</div></div>
              <div><div style={{ fontSize:10,color:"#555",fontFamily:"sans-serif",marginBottom:3 }}>MONTO</div><div style={{ fontSize:15,color:GOLD,fontWeight:"bold" }}>{p.monto}</div></div>
            </div>
          </div>

          <div style={{ background:CARD, border:`1px solid ${GOLD}44`, borderRadius:12, padding:"16px", marginBottom:16 }}>
            <div style={{ fontSize:11, color:GOLD, fontFamily:"sans-serif", letterSpacing:"2px", marginBottom:10 }}>📋 NÚMERO DE SERIE</div>
            <input
              placeholder="Ej: PED-2026-001"
              value={p.serie || ""}
              onChange={e => setPedidos(pedidos.map((x,i) => i===selected ? {...x, serie:e.target.value.toUpperCase()} : x))}
              style={{ width:"100%", background:DARK3, border:`1px solid ${GOLD}55`, color:GOLD, padding:"12px 14px", borderRadius:8, fontSize:15, fontFamily:"sans-serif", outline:"none", boxSizing:"border-box", fontWeight:"bold", letterSpacing:"2px" }}
            />
            <div style={{ fontSize:10, color:"#555", fontFamily:"sans-serif", marginTop:4 }}>Visible para el cliente · Se guarda automáticamente</div>
          </div>
          <div style={{ background:CARD,border:`1px solid ${BORDER}`,borderRadius:12,padding:"16px",marginBottom:20 }}>
            <div style={{ fontSize:11,color:GOLD,fontFamily:"sans-serif",letterSpacing:"2px",marginBottom:12 }}>⏱ DÍAS HÁBILES DE ENTREGA</div>
            <div style={{ fontSize:12,color:"#888",fontFamily:"sans-serif",marginBottom:10 }}>Desde fecha del pedido · Solo Lunes a Viernes</div>
            <div style={{ display:"flex",gap:8,alignItems:"center",marginBottom:12 }}>
              <button onClick={() => setDiasHabiles((p.diasHabiles||10)-1)} style={{ width:40,height:40,background:DARK3,border:`1px solid ${BORDER}`,color:"#F0F0F0",borderRadius:8,fontSize:20,cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0 }}>−</button>
              <div style={{ flex:1,textAlign:"center" }}>
                <div style={{ fontSize:32,fontWeight:"bold",color:GOLD }}>{p.diasHabiles||10}</div>
                <div style={{ fontSize:11,color:"#888",fontFamily:"sans-serif" }}>días hábiles</div>
              </div>
              <button onClick={() => setDiasHabiles((p.diasHabiles||10)+1)} style={{ width:40,height:40,background:DARK3,border:`1px solid ${BORDER}`,color:"#F0F0F0",borderRadius:8,fontSize:20,cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0 }}>+</button>
            </div>
            <div style={{ display:"flex",gap:8,flexWrap:"wrap" }}>
              {[5,8,10,15,20].map(n => (
                <button key={n} onClick={() => setDiasHabiles(n)} style={{ flex:1,minWidth:50,padding:"8px 4px",borderRadius:8,border:`1px solid ${(p.diasHabiles||10)===n?GOLD:BORDER}`,background:(p.diasHabiles||10)===n?GOLD+"18":DARK3,color:(p.diasHabiles||10)===n?GOLD:"#888",fontFamily:"sans-serif",fontSize:13,cursor:"pointer",fontWeight:(p.diasHabiles||10)===n?"bold":"normal" }}>{n}d</button>
              ))}
            </div>
            {lim && <div style={{ marginTop:12,padding:"10px 14px",background:DARK3,borderRadius:8,display:"flex",justifyContent:"space-between",alignItems:"center" }}>
              <div style={{ fontSize:12,color:"#888",fontFamily:"sans-serif" }}>Fecha límite calculada</div>
              <div style={{ fontSize:14,color:GOLD,fontWeight:"bold",fontFamily:"sans-serif" }}>{formatFechaCorta(lim)}</div>
            </div>}
          </div>

          <div style={{ background:`${GOLD}11`,border:`1px solid ${GOLD}22`,borderRadius:12,padding:"16px",marginBottom:20 }}>
            <div style={{ display:"flex",justifyContent:"space-between",marginBottom:10 }}>
              <div style={{ fontSize:11,color:GOLD,fontFamily:"sans-serif",letterSpacing:"2px" }}>PROGRESO</div>
              <div style={{ fontSize:13,color:GOLD,fontWeight:"bold" }}>{pct}%</div>
            </div>
            <div style={{ background:"#1A1A1A",borderRadius:6,height:8,overflow:"hidden" }}>
              <div style={{ background:`linear-gradient(90deg,${GOLD},${GOLD_LIGHT})`,width:`${pct}%`,height:"100%",borderRadius:6,boxShadow:`0 0 8px ${GOLD}66` }} />
            </div>
          </div>

          <div style={{ fontSize:11,color:GOLD,fontFamily:"sans-serif",letterSpacing:"2px",marginBottom:12 }}>CAMBIAR ESTADO</div>
          <div style={{ display:"flex",flexDirection:"column",gap:8,marginBottom:24 }}>
            {ESTADO_LABELS.map((est,i) => (
              <button key={i} onClick={() => setPedidos(pedidos.map((x,j)=>j===selected?{...x,estado:i}:x))}
                style={{ padding:"12px 16px",borderRadius:10,border:`1px solid ${p.estado===i?GOLD:BORDER}`,background:p.estado===i?GOLD+"18":CARD,cursor:"pointer",display:"flex",alignItems:"center",gap:12,textAlign:"left" }}>
                <span style={{ fontSize:18 }}>{ESTADO_ICONS[i]}</span>
                <span style={{ fontSize:14,color:p.estado===i?GOLD:"#AAA",fontFamily:"sans-serif",fontWeight:p.estado===i?"bold":"normal",flex:1 }}>{est}</span>
                {p.estado===i && <span style={{ fontSize:12,color:GOLD }}>✓ Actual</span>}
              </button>
            ))}
          </div>

          <div style={{ fontSize:11,color:GOLD,fontFamily:"sans-serif",letterSpacing:"2px",marginBottom:12 }}>📸 FOTOS DE PRODUCCIÓN</div>
          <div style={{ background:CARD,border:`1px solid ${BORDER}`,borderRadius:12,padding:"16px",marginBottom:20 }}>
            <div style={{ fontSize:12,color:"#888",fontFamily:"sans-serif",marginBottom:8 }}>Nota para esta foto (opcional)</div>
            <input placeholder="Ej: Soldadura terminada…" value={nota} onChange={e=>setNota(e.target.value)}
              style={{ width:"100%",background:DARK3,border:`1px solid ${BORDER}`,color:"#F0F0F0",padding:"12px 14px",borderRadius:8,fontSize:14,fontFamily:"sans-serif",outline:"none",boxSizing:"border-box",marginBottom:12 }} />
            <PhotoUploadButton onPhoto={addFoto} label="📷 Subir foto del progreso" style={{ width:"100%",justifyContent:"center",boxSizing:"border-box" }} />
            {p.fotos?.length > 0 && (
              <div style={{ marginTop:14,display:"flex",flexDirection:"column",gap:10 }}>
                {p.fotos.map((f,i) => (
                  <div key={i} style={{ borderRadius:10,overflow:"hidden",border:`1px solid ${BORDER}` }}>
                    <img src={f.src} alt="Progreso" style={{ width:"100%",maxHeight:180,objectFit:"cover",display:"block" }} />
                    <div style={{ padding:"8px 12px",background:DARK3 }}>
                      {f.nota && <div style={{ fontSize:13,color:"#CCC",fontFamily:"sans-serif",marginBottom:4 }}>{f.nota}</div>}
                      <div style={{ fontSize:11,color:"#555",fontFamily:"sans-serif" }}>{ESTADO_LABELS[f.etapa]} · {f.fecha} · {f.autor}</div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
          <a href={`https://wa.me/595${p.tel.replace(/\D/g,"").replace(/^0/,"")}?text=Hola ${cliente?.nombre?.split(" ")[0]||""}! Tu pedido ${p.id} está en: ${ESTADO_LABELS[p.estado]}`} target="_blank" rel="noreferrer"
            style={{ display:"flex",alignItems:"center",justifyContent:"center",gap:8,background:"#0A1F0A",border:"1px solid #1A3A1A",borderRadius:10,padding:"14px",textDecoration:"none",color:"#4CAF50",fontFamily:"sans-serif",fontSize:14 }}>
            💬 Notificar al cliente por WhatsApp
          </a>
        </div>
      </div>
    );
  }

  const stats = [
    { label:"Total",          value:pedidos.length,                                       color:GOLD,      icon:"📦" },
    { label:"Producción",     value:pedidos.filter(p=>p.estado===1||p.estado===2).length, color:GOLD,      icon:"⚙️" },
    { label:"Para entregar",  value:pedidos.filter(p=>p.estado===3).length,               color:"#4CAF50", icon:"🚀" },
    { label:"Entregados",     value:pedidos.filter(p=>p.estado===4).length,               color:"#4CAF50", icon:"✅" },
  ];
  return (
    <div style={{ paddingBottom:80 }}>
      <div style={{ padding:"20px 20px 16px", borderBottom:`1px solid ${BORDER}`, display:"flex", justifyContent:"space-between", alignItems:"center" }}>
        <div>
          <div style={{ fontSize:10, color:GOLD, fontFamily:"sans-serif", letterSpacing:"3px", marginBottom:4 }}>PANEL DE GESTIÓN</div>
          <div style={{ fontSize:22, fontWeight:"bold" }}>Pedidos</div>
        </div>
        <button onClick={() => setView("new")} style={{ background:`linear-gradient(135deg,${GOLD},${GOLD_LIGHT})`, border:"none", color:DARK, padding:"10px 18px", borderRadius:10, fontSize:13, fontFamily:"sans-serif", fontWeight:"bold", cursor:"pointer" }}>
          ➕ Nuevo pedido
        </button>
      </div>
      <AlertaBanner pedidos={pedidos} />
      <div style={{ padding:"16px",display:"grid",gridTemplateColumns:"1fr 1fr",gap:10,marginBottom:4 }}>
        {stats.map(s => (
          <div key={s.label} style={{ background:CARD, border:`1px solid ${BORDER}`, borderRadius:10, padding:"14px", textAlign:"center" }}>
            <div style={{ fontSize:18, marginBottom:4 }}>{s.icon}</div>
            <div style={{ fontSize:26, fontWeight:"bold", color:s.color }}>{s.value}</div>
            <div style={{ fontSize:10, color:"#666", fontFamily:"sans-serif", marginTop:2 }}>{s.label}</div>
          </div>
        ))}
      </div>
      <div style={{ padding:"0 16px",display:"flex",flexDirection:"column",gap:10 }}>
        {pedidos.filter(p => filterStatus==="all" || String(p.estado)===filterStatus).map((p,i) => {
          const base = parseFecha(p.fecha);
          const lim = base && p.diasHabiles ? addDiasHabiles(base, p.diasHabiles) : null;
          const dias = lim ? diasHabilesRestantes(lim) : null;
          const alertColor = dias !== null && p.estado < 4 ? getAlertaColor(dias) : null;
          return (
            <button key={p.id} onClick={() => setSelected(i)} style={{ background:CARD,border:`1px solid ${alertColor||BORDER}`,borderRadius:12,padding:"16px",cursor:"pointer",textAlign:"left" }}>
              <div style={{ display:"flex",justifyContent:"space-between",marginBottom:6 }}>
                <div style={{ display:"flex", alignItems:"center", gap:8 }}>
                <div style={{ fontSize:13, color:GOLD, fontFamily:"sans-serif", fontWeight:"bold" }}>{p.id}</div>
                {p.serie && <span style={{ background:GOLD+"22", border:`1px solid ${GOLD}44`, color:GOLD, fontSize:9, padding:"2px 7px", borderRadius:20, fontFamily:"sans-serif", fontWeight:"bold", letterSpacing:"1px" }}>{p.serie}</span>}
              </div>
                <div style={{ background:tc[p.estado]+"22",color:tc[p.estado],fontSize:11,padding:"3px 10px",borderRadius:20,fontFamily:"sans-serif",border:`1px solid ${tc[p.estado]}44` }}>{ESTADO_LABELS[p.estado]}</div>
              </div>
              <div style={{ fontSize:15,fontWeight:"bold",marginBottom:2 }}>{getNombre(p.tel)}</div>
              <div style={{ fontSize:13,color:"#888",fontFamily:"sans-serif",marginBottom:10,display:"flex",justifyContent:"space-between",alignItems:"center" }}>
                <span>{p.modelo}</span>
                {dias !== null && p.estado < 4 && <CountdownBadge fecha={p.fecha} diasHabiles={p.diasHabiles} size="small" />}
              </div>
              <div style={{ background:BORDER,borderRadius:4,height:3 }}>
                <div style={{ background:`linear-gradient(90deg,${GOLD},${GOLD_LIGHT})`,width:`${Math.round((p.estado/(ESTADO_LABELS.length-1))*100)}%`,height:"100%",borderRadius:4 }} />
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}

// ── ADMIN: TICKETS ────────────────────────────────────────────────────────────
function AdminTickets({ tickets, setTickets, clientes }) {
  const [selected, setSelected] = useState(null);
  const sc = { "Abierto":"#E57373","En proceso":GOLD,"Resuelto":"#4CAF50" };
  const next = { "Abierto":"En proceso","En proceso":"Resuelto" };
  const getNombre = (tel) => { const c=clientes.find(x=>normalizePhone(x.tel)===normalizePhone(tel)); return c?c.nombre:tel; };
  if (selected !== null) {
    const t = tickets[selected];
    return (
      <div style={{ paddingBottom:80 }}>
        <Header title={t.id} subtitle="DETALLE DE TICKET" back onBack={() => setSelected(null)} />
        <div style={{ padding:"20px" }}>
          <div style={{ background:CARD,border:`1px solid ${BORDER}`,borderRadius:12,padding:"16px 20px",marginBottom:20 }}>
            <div style={{ display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:12 }}>
              <Tag label={t.tipo} color={sc[t.estado]} />
              <div style={{ background:sc[t.estado]+"22",color:sc[t.estado],fontSize:12,padding:"4px 12px",borderRadius:20,fontFamily:"sans-serif",fontWeight:"bold" }}>{t.estado}</div>
            </div>
            <div style={{ fontSize:11,color:"#555",fontFamily:"sans-serif",marginBottom:4 }}>CLIENTE</div>
            <div style={{ fontSize:18,fontWeight:"bold",marginBottom:14 }}>{getNombre(t.tel)}</div>
            <div style={{ height:1,background:BORDER,marginBottom:14 }} />
            <div style={{ fontSize:14,color:"#CCC",fontFamily:"sans-serif",lineHeight:1.6 }}>{t.desc}</div>
            <div style={{ fontSize:11,color:"#555",fontFamily:"sans-serif",marginTop:12 }}>📅 {t.fecha}</div>
          </div>
          {t.estado!=="Resuelto" && <button onClick={() => { setTickets(tickets.map((x,i)=>i===selected?{...x,estado:next[x.estado]}:x)); setSelected(null); }} style={{ width:"100%",background:`linear-gradient(135deg,${GOLD},${GOLD_LIGHT})`,border:"none",color:DARK,padding:"16px",borderRadius:10,fontSize:15,fontFamily:"sans-serif",fontWeight:"bold",cursor:"pointer",marginBottom:12 }}>→ MARCAR COMO {next[t.estado].toUpperCase()}</button>}
          {t.estado==="Resuelto" && <div style={{ background:"#0A1F0A",border:"1px solid #1A3A1A",borderRadius:10,padding:"16px",textAlign:"center",color:"#4CAF50",fontFamily:"sans-serif",fontWeight:"bold" }}>✅ TICKET RESUELTO</div>}
        </div>
      </div>
    );
  }
  const stats = [
    { label:"Abiertos",value:tickets.filter(t=>t.estado==="Abierto").length,color:"#E57373" },
    { label:"En proceso",value:tickets.filter(t=>t.estado==="En proceso").length,color:GOLD },
    { label:"Resueltos",value:tickets.filter(t=>t.estado==="Resuelto").length,color:"#4CAF50" },
  ];
  return (
    <div style={{ paddingBottom:80 }}>
      <div style={{ padding:"20px 20px 16px",borderBottom:`1px solid ${BORDER}` }}>
        <div style={{ fontSize:10,color:GOLD,fontFamily:"sans-serif",letterSpacing:"3px",marginBottom:4 }}>PANEL DE GESTIÓN</div>
        <div style={{ fontSize:22,fontWeight:"bold" }}>Soporte</div>
      </div>
      <div style={{ padding:"16px",display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:10,marginBottom:4 }}>
        {stats.map(s => <div key={s.label} style={{ background:CARD,border:`1px solid ${BORDER}`,borderRadius:10,padding:"12px",textAlign:"center" }}><div style={{ fontSize:24,fontWeight:"bold",color:s.color }}>{s.value}</div><div style={{ fontSize:10,color:"#666",fontFamily:"sans-serif",marginTop:2 }}>{s.label}</div></div>)}
      </div>
      <div style={{ padding:"0 16px",display:"flex",flexDirection:"column",gap:10 }}>
        {tickets.map((t,i) => (
          <button key={t.id} onClick={() => setSelected(i)} style={{ background:CARD,border:`1px solid ${BORDER}`,borderRadius:12,padding:"16px",cursor:"pointer",textAlign:"left" }}>
            <div style={{ display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:6 }}>
              <div style={{ display:"flex",gap:8,alignItems:"center" }}><span style={{ fontSize:12,color:"#666",fontFamily:"sans-serif" }}>{t.id}</span><Tag label={t.tipo} color={sc[t.estado]} /></div>
              <div style={{ background:sc[t.estado]+"22",color:sc[t.estado],fontSize:11,padding:"3px 10px",borderRadius:20,fontFamily:"sans-serif" }}>{t.estado}</div>
            </div>
            <div style={{ fontSize:14,color:"#CCC",fontFamily:"sans-serif",marginBottom:4 }}>{getNombre(t.tel)}</div>
            <div style={{ fontSize:13,color:"#888",fontFamily:"sans-serif",lineHeight:1.5 }}>{t.desc.slice(0,70)}…</div>
            <div style={{ fontSize:11,color:"#555",fontFamily:"sans-serif",marginTop:8 }}>{t.fecha}</div>
          </button>
        ))}
      </div>
    </div>
  );
}

// ── ROOT ──────────────────────────────────────────────────────────────────────
// ── ADMIN: RESENAS ────────────────────────────────────────────────────────────
function AdminResenas({ pedidos, clientes }) {
  const resenas = pedidos.filter(p => p.resena).map(p => {
    const cliente = clientes.find(c => normalizePhone(c.tel)===normalizePhone(p.tel));
    return { ...p.resena, cliente: cliente?.nombre || p.tel, modelo: p.modelo, pedidoId: p.id };
  });

  const avg = resenas.length > 0
    ? (resenas.reduce((s,r) => s+r.stars, 0) / resenas.length).toFixed(1)
    : "—";

  const dist = [5,4,3,2,1].map(s => ({
    stars: s,
    count: resenas.filter(r=>r.stars===s).length,
    pct: resenas.length > 0 ? Math.round(resenas.filter(r=>r.stars===s).length/resenas.length*100) : 0
  }));

  const starColor = (s) => s>=4?"#4CAF50":s===3?GOLD:"#E57373";

  return (
    <div style={{ paddingBottom:80 }}>
      <div style={{ padding:"20px 20px 16px", borderBottom:`1px solid ${BORDER}` }}>
        <div style={{ fontSize:10, color:GOLD, fontFamily:"sans-serif", letterSpacing:"3px", marginBottom:4 }}>PANEL DE GESTION</div>
        <div style={{ fontSize:22, fontWeight:"bold" }}>Resenas</div>
      </div>

      {/* Summary */}
      <div style={{ padding:"16px", display:"grid", gridTemplateColumns:"1fr 2fr", gap:12, marginBottom:4 }}>
        <div style={{ background:CARD, border:`1px solid ${BORDER}`, borderRadius:12, padding:"20px", textAlign:"center" }}>
          <div style={{ fontSize:42, fontWeight:"bold", color:GOLD }}>{avg}</div>
          <div style={{ fontSize:24, marginBottom:4 }}>⭐</div>
          <div style={{ fontSize:11, color:"#666", fontFamily:"sans-serif" }}>{resenas.length} resenas</div>
        </div>
        <div style={{ background:CARD, border:`1px solid ${BORDER}`, borderRadius:12, padding:"16px" }}>
          {dist.map(d => (
            <div key={d.stars} style={{ display:"flex", alignItems:"center", gap:8, marginBottom:6 }}>
              <span style={{ fontSize:11, color:"#888", fontFamily:"sans-serif", minWidth:12 }}>{d.stars}</span>
              <span style={{ fontSize:11 }}>⭐</span>
              <div style={{ flex:1, background:BORDER, borderRadius:4, height:8, overflow:"hidden" }}>
                <div style={{ background:starColor(d.stars), width:`${d.pct}%`, height:"100%", borderRadius:4 }}/>
              </div>
              <span style={{ fontSize:11, color:"#888", fontFamily:"sans-serif", minWidth:24 }}>{d.count}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Google Reviews CTA for admin */}
      <div style={{ margin:"0 16px 16px" }}>
        <a href={GOOGLE_REVIEW_URL} target="_blank" rel="noreferrer"
          style={{ display:"flex", alignItems:"center", gap:12, background:"#0A0F1F", border:"1px solid #1A2A4A", borderRadius:12, padding:"14px 16px", textDecoration:"none" }}>
          <span style={{ fontSize:24 }}>🔍</span>
          <div>
            <div style={{ fontSize:13, fontWeight:"bold", color:"#4285F4" }}>Ver tu perfil de Google</div>
            <div style={{ fontSize:11, color:"#666", fontFamily:"sans-serif" }}>Responde las resenas publicas</div>
          </div>
          <span style={{ marginLeft:"auto", color:"#4285F4", fontSize:18 }}>›</span>
        </a>
      </div>

      {/* Individual reviews */}
      <div style={{ padding:"0 16px", display:"flex", flexDirection:"column", gap:10 }}>
        {resenas.length === 0 && (
          <div style={{ textAlign:"center", padding:"40px 20px", color:"#555", fontFamily:"sans-serif" }}>
            <div style={{ fontSize:40, marginBottom:12 }}>⭐</div>
            <div>Aun no hay resenas. Se muestran aqui cuando los clientes califiquen sus pedidos.</div>
          </div>
        )}
        {resenas.sort((a,b) => b.stars-a.stars).map((r,i) => (
          <div key={i} style={{ background:CARD, border:`1px solid ${starColor(r.stars)}44`, borderRadius:12, padding:"16px" }}>
            <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:8 }}>
              <div>
                <div style={{ fontSize:14, fontWeight:"bold", marginBottom:2 }}>{r.cliente}</div>
                <div style={{ fontSize:11, color:"#666", fontFamily:"sans-serif" }}>{r.modelo} · {r.pedidoId}</div>
              </div>
              <div style={{ display:"flex", gap:2 }}>
                {[1,2,3,4,5].map(s => <span key={s} style={{ fontSize:16 }}>{s<=r.stars?"⭐":"☆"}</span>)}
              </div>
            </div>
            {r.comment && (
              <div style={{ fontSize:13, color:"#AAA", fontFamily:"sans-serif", fontStyle:"italic", lineHeight:1.6, padding:"10px 12px", background:DARK3, borderRadius:8, marginBottom:8 }}>
                "{r.comment}"
              </div>
            )}
            <div style={{ fontSize:11, color:"#555", fontFamily:"sans-serif" }}>{r.fecha}</div>
          </div>
        ))}
      </div>
    </div>
  );
}


export default function App() {
  const [logged, setLogged]           = useState(false);
  const [isAdmin, setIsAdmin]         = useState(false);
  const [adminUser, setAdminUser]     = useState(null);
  const [clienteUser, setClienteUser] = useState(null);
  const [active, setActive]           = useState("home");
  const [pedidos, setPedidos]         = useState(INITIAL_PEDIDOS);
  const [tickets, setTickets]         = useState(INITIAL_TICKETS);
  const [clientes, setClientes]       = useState(INITIAL_CLIENTES);
  const [productos, setProductos]     = useState(INITIAL_PRODUCTOS);
  const [storageReady, setStorageReady] = useState(false);
  const [savingIndicator, setSavingIndicator] = useState(false);
  const [firebaseOk, setFirebaseOk] = useState(false);

  // ── Load from storage on mount + check Firebase ──
  React.useEffect(() => {
    const load = async () => {
      const fbOk = await checkFirebase();
      setFirebaseOk(fbOk);
      try { const r1 = await appStorage.get("dp_clientes");  if (r1) setClientes(JSON.parse(r1));  } catch(e) {}
      try { const r2 = await appStorage.get("dp_pedidos");   if (r2) setPedidos(JSON.parse(r2));   } catch(e) {}
      try { const r3 = await appStorage.get("dp_tickets");   if (r3) setTickets(JSON.parse(r3));   } catch(e) {}
      try { const r4 = await appStorage.get("dp_productos"); if (r4) setProductos(JSON.parse(r4)); } catch(e) {}
      setStorageReady(true);
    };
    load();
  }, []);

  // ── Polling: sync from Firebase every 30 seconds ──
  React.useEffect(() => {
    if (!firebaseOk || !FIREBASE_URL) return;
    const poll = setInterval(async () => {
      try { const r1 = await appStorage.get("dp_clientes");  if (r1) setClientes(JSON.parse(r1));  } catch(e) {}
      try { const r2 = await appStorage.get("dp_pedidos");   if (r2) setPedidos(JSON.parse(r2));   } catch(e) {}
      try { const r3 = await appStorage.get("dp_tickets");   if (r3) setTickets(JSON.parse(r3));   } catch(e) {}
    }, 30000);
    return () => clearInterval(poll);
  }, [firebaseOk]);

  // ── Auto-save whenever data changes ──
  React.useEffect(() => {
    if (!storageReady) return;
    const save = async () => {
      setSavingIndicator(true);
      await appStorage.set("dp_clientes",  JSON.stringify(clientes));
      await appStorage.set("dp_pedidos",   JSON.stringify(pedidos));
      await appStorage.set("dp_tickets",   JSON.stringify(tickets));
      await appStorage.set("dp_productos", JSON.stringify(productos));
      setTimeout(() => setSavingIndicator(false), 800);
    };
    save();
  }, [clientes, pedidos, tickets, productos, storageReady]);

  if (!logged) return (
    <div style={{ fontFamily:"Georgia, serif",background:DARK,color:"#F0F0F0",minHeight:"100vh",maxWidth:430,margin:"0 auto" }}>
      <LoginScreen clientes={clientes} onLogin={(admin,cliente,esAdmin) => { setAdminUser(admin); setClienteUser(cliente); setIsAdmin(esAdmin); setActive(esAdmin?"admin-orders":"home"); setLogged(true); }} />
    </div>
  );

  const screens = {
    home:             () => <HomeScreen setActive={setActive} clienteUser={clienteUser} pedidos={pedidos} />,
    catalogo:         () => <CatalogoScreen productos={productos} />,
    pedidos:          () => <PedidosScreen setPedidos={setPedidos} pedidos={pedidos} clienteUser={clienteUser} />,
    soporte:          () => <SoporteScreen tickets={tickets} setTickets={setTickets} clienteUser={clienteUser} />,
    "admin-orders":   () => <AdminOrders pedidos={pedidos} setPedidos={setPedidos} clientes={clientes} adminUser={adminUser} productos={productos} />,
    "admin-tickets":  () => <AdminTickets tickets={tickets} setTickets={setTickets} clientes={clientes} />,
    "admin-clientes": () => <AdminClientes clientes={clientes} setClientes={setClientes} />,
    "admin-catalog":  () => <AdminCatalog productos={productos} setProductos={setProductos} />,
  };
  const Screen = screens[active] || screens["home"];

  return (
    <div style={{ fontFamily:"Georgia, serif",background:DARK,color:"#F0F0F0",minHeight:"100vh",maxWidth:430,margin:"0 auto",position:"relative" }}>
      <div style={{ background:"#080808", padding:"10px 20px 6px", display:"flex", justifyContent:"space-between", alignItems:"center", fontSize:11, color:"#555", fontFamily:"sans-serif" }}>
        <span style={{ fontSize:10, minWidth:50, fontFamily:"sans-serif" }}>
          {savingIndicator
            ? <span style={{ color:GOLD }}>💾 ...</span>
            : FIREBASE_URL
              ? <span style={{ color: firebaseOk ? "#4CAF50" : "#E57373" }}>{firebaseOk ? "🔥 sync" : "📵 local"}</span>
              : <span style={{ color:"#555" }}>📵 local</span>
          }
        </span>
        <img src={LOGO_B64} alt="Dr. Parrilla" style={{ height:16, width:"auto", opacity:0.9 }} />
        <span onClick={() => { setLogged(false);setActive("home");setAdminUser(null);setClienteUser(null);setIsAdmin(false); }} style={{ cursor:"pointer", color:"#E57373" }}>Salir</span>
      </div>
      {isAdmin && adminUser && (
        <div style={{ background:"#0D0500", padding:"5px 16px", fontSize:10, fontFamily:"sans-serif", letterSpacing:"1px", display:"flex", justifyContent:"space-between", alignItems:"center" }}>
          <span style={{ color:GOLD }}>{adminUser.nombre} · {adminUser.rol}</span>
          {FIREBASE_URL
            ? <span style={{ color: firebaseOk ? "#4CAF50" : "#E57373" }}>
                {firebaseOk ? "🔥 Firebase sync" : "⚠️ Sin conexión"}
              </span>
            : <span style={{ color:"#666" }}>💾 Local — configura Firebase</span>
          }
        </div>
      )}
      <div style={{ overflowY:"auto",maxHeight:"calc(100vh - 120px)" }}>
        <Screen />
      </div>
      <BottomNav active={active} setActive={setActive} isAdmin={isAdmin} />
    </div>
  );
}
